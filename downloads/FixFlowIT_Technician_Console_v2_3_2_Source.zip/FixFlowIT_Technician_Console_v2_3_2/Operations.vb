Imports System
Imports System.Collections.Generic
Imports System.Drawing
Imports System.IO
Imports System.Linq
Imports System.Net
Imports System.Net.NetworkInformation
Imports System.Text
Imports System.Text.Json
Imports System.Threading.Tasks
Imports System.Windows.Forms

Public Class MaintenanceRecord
    Public Property Id As Integer
    Public Property TicketId As Integer
    Public Property DeviceId As Integer
    Public Property CustomerId As Integer
    Public Property TaskTitle As String = ""
    Public Property Technician As String = ""
    Public Property Status As String = "Scheduled"
    Public Property ScheduledDate As DateTime = DateTime.Today
    Public Property CompletedDate As Nullable(Of DateTime)
    Public Property WorkPerformed As String = ""
    Public Property PartsUsed As String = ""
    Public Property LaborHours As Decimal
    Public Property PartsCost As Decimal
    Public Property LaborRate As Decimal
    Public Property Updated As DateTime = DateTime.Now
End Class

Public Partial Class MainForm
    Private ReadOnly maintenanceRecords As New List(Of MaintenanceRecord)()
    Private ReadOnly maintenanceFile As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FixFlowIT", "maintenance.json")
    Private ReadOnly maintenanceGrid As New DataGridView()
    Private ReadOnly maintenanceTitle As New TextBox()
    Private ReadOnly maintenanceTech As New TextBox()
    Private ReadOnly maintenanceStatus As New ComboBox()
    Private ReadOnly maintenanceDate As New DateTimePicker()
    Private ReadOnly maintenanceCustomer As New ComboBox()
    Private ReadOnly maintenanceDevice As New ComboBox()
    Private ReadOnly maintenanceTicket As New ComboBox()
    Private ReadOnly maintenanceWork As New TextBox()
    Private ReadOnly maintenanceParts As New TextBox()
    Private ReadOnly maintenanceHours As New NumericUpDown()
    Private ReadOnly maintenanceRate As New NumericUpDown()
    Private ReadOnly maintenancePartsCost As New NumericUpDown()
    Private ReadOnly maintenanceInfo As New Label()
    Private selectedMaintenanceId As Integer = -1
    Private ReadOnly repairGrid As New DataGridView()
    Private ReadOnly repairSearch As New TextBox()
    Private ReadOnly repairDetail As New TextBox()
    Private ReadOnly reportSummary As New Label()
    Private ReadOnly reportGrid As New DataGridView()
    Private ReadOnly reportKind As New ComboBox()
    Private ReadOnly diagnosticTarget As New TextBox()
    Private ReadOnly diagnosticOutput As New TextBox()
    Private ReadOnly cidrInput As New TextBox()
    Private ReadOnly cidrOutput As New Label()

    Private Class RecordChoice
        Public Property Id As Integer
        Public Property Label As String = ""
        Public Overrides Function ToString() As String
            Return Label
        End Function
    End Class

    Private Function MakeOpsGrid() As DataGridView
        Return New DataGridView With {
            .ReadOnly = True, .AllowUserToAddRows = False, .AllowUserToDeleteRows = False,
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect, .MultiSelect = False,
            .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            .BackgroundColor = panelBg, .BorderStyle = BorderStyle.None,
            .RowHeadersVisible = False, .AutoGenerateColumns = True
        }
    End Function

    Private Sub ConfigureOpsGrid(target As DataGridView)
        target.ReadOnly = True
        target.AllowUserToAddRows = False
        target.AllowUserToDeleteRows = False
        target.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        target.MultiSelect = False
        target.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        target.RowHeadersVisible = False
        target.BackgroundColor = panelBg
        target.BorderStyle = BorderStyle.None
    End Sub

    Private Sub AddOpsLabel(page As TabPage, caption As String, x As Integer, y As Integer, Optional width As Integer = 210)
        page.Controls.Add(MakeLabel(caption, x, y, width))
    End Sub

    Private Sub AddOpsText(page As TabPage, controlItem As TextBox, x As Integer, y As Integer, width As Integer, Optional height As Integer = 30)
        controlItem.SetBounds(x, y, width, height)
        page.Controls.Add(controlItem)
    End Sub

    Private Sub AddOpsChoice(page As TabPage, choice As ComboBox, x As Integer, y As Integer, width As Integer)
        choice.SetBounds(x, y, width, 30)
        choice.DropDownStyle = ComboBoxStyle.DropDownList
        page.Controls.Add(choice)
    End Sub

    Private Sub BuildDiagnosticsPage()
        Dim page = AddPage("Network Diagnostics")
        page.AutoScroll = True
        AddOpsLabel(page, "NETWORK DIAGNOSTICS  /  Connectivity and IPv4 tools", 25, 20, 800)
        AddOpsLabel(page, "Hostname or IP address", 25, 70, 280)
        AddOpsText(page, diagnosticTarget, 25, 100, 450)
        page.Controls.Add(MakeButton("Ping Host", 490, 97, 155, AddressOf RunPing))
        page.Controls.Add(MakeButton("DNS Lookup", 658, 97, 155, AddressOf RunDns))
        AddOpsLabel(page, "Results", 25, 152)
        diagnosticOutput.SetBounds(25, 180, 1010, 220)
        diagnosticOutput.Multiline = True
        diagnosticOutput.ReadOnly = True
        diagnosticOutput.ScrollBars = ScrollBars.Vertical
        diagnosticOutput.Font = New Font("Consolas", 10.0F)
        diagnosticOutput.Text = "Enter a hostname or IP address and choose a diagnostic."
        page.Controls.Add(diagnosticOutput)
        AddOpsLabel(page, "IPv4 subnet calculator", 25, 425, 400)
        AddOpsLabel(page, "Address/CIDR (example: 192.168.1.24/24)", 25, 462, 520)
        AddOpsText(page, cidrInput, 25, 493, 430)
        page.Controls.Add(MakeButton("Calculate Subnet", 475, 490, 190, AddressOf CalculateSubnet))
        cidrOutput.SetBounds(25, 545, 1010, 120)
        cidrOutput.AutoSize = False
        cidrOutput.Font = New Font("Consolas", 10.0F)
        page.Controls.Add(cidrOutput)
        AddOpsLabel(page, "Diagnostics run from this computer and only on networks you are authorized to test.", 25, 685, 900)
    End Sub

    Private Async Sub RunPing(sender As Object, e As EventArgs)
        Dim hostName = diagnosticTarget.Text.Trim()
        If hostName.Length = 0 Then
            MessageBox.Show("Enter a hostname or IP address.")
            Return
        End If
        Dim buttonItem = DirectCast(sender, Button)
        buttonItem.Enabled = False
        diagnosticOutput.Text = "Pinging " & hostName & " ..." & Environment.NewLine
        Try
            Using pingClient As New Ping()
                Dim results As New List(Of String)()
                For index As Integer = 1 To 4
                    Dim reply = Await pingClient.SendPingAsync(hostName, 2000)
                    If reply.Status = IPStatus.Success Then
                        results.Add($"Reply {index}: {reply.Address}  {reply.RoundtripTime} ms")
                    Else
                        results.Add($"Reply {index}: {reply.Status}")
                    End If
                Next
                diagnosticOutput.Text = String.Join(Environment.NewLine, results)
            End Using
        Catch ex As Exception
            diagnosticOutput.Text = "Ping failed: " & ex.Message
        Finally
            buttonItem.Enabled = True
        End Try
    End Sub

    Private Async Sub RunDns(sender As Object, e As EventArgs)
        Dim hostName = diagnosticTarget.Text.Trim()
        If hostName.Length = 0 Then
            MessageBox.Show("Enter a hostname or IP address.")
            Return
        End If
        Dim buttonItem = DirectCast(sender, Button)
        buttonItem.Enabled = False
        diagnosticOutput.Text = "Resolving " & hostName & " ..."
        Try
            Dim addresses = Await Dns.GetHostAddressesAsync(hostName)
            diagnosticOutput.Text = If(addresses.Length = 0, "No addresses found.", String.Join(Environment.NewLine, addresses.Select(Function(addressItem) addressItem.ToString())))
        Catch ex As Exception
            diagnosticOutput.Text = "DNS lookup failed: " & ex.Message
        Finally
            buttonItem.Enabled = True
        End Try
    End Sub

    Private Sub CalculateSubnet(sender As Object, e As EventArgs)
        Dim parts = cidrInput.Text.Trim().Split("/"c)
        Dim parsed As IPAddress = Nothing
        Dim prefix As Integer
        If parts.Length <> 2 OrElse Not IPAddress.TryParse(parts(0), parsed) OrElse parsed.AddressFamily <> System.Net.Sockets.AddressFamily.InterNetwork OrElse Not Integer.TryParse(parts(1), prefix) OrElse prefix < 0 OrElse prefix > 32 Then
            cidrOutput.Text = "Invalid IPv4/CIDR. Example: 192.168.1.24/24"
            Return
        End If
        Dim bytes = parsed.GetAddressBytes()
        Dim ipValue As ULong = 0UL
        For Each octet As Byte In bytes
            ipValue = (ipValue << 8) Or CULng(octet)
        Next
        Dim mask As ULong = If(prefix = 0, 0UL, (4294967295UL << (32 - prefix)) And 4294967295UL)
        Dim network As ULong = ipValue And mask
        Dim broadcast As ULong = network Or (4294967295UL Xor mask)
        Dim hostCount As ULong = If(prefix >= 31, If(prefix = 31, 2UL, 1UL), (1UL << (32 - prefix)) - 2UL)
        cidrOutput.Text = $"Subnet mask: {Ipv4Text(mask)}    Network: {Ipv4Text(network)}{Environment.NewLine}" &
            $"Broadcast: {Ipv4Text(broadcast)}    Usable addresses: {hostCount:N0}{Environment.NewLine}" &
            $"First address: {Ipv4Text(If(prefix < 31, network + 1UL, network))}    Last address: {Ipv4Text(If(prefix < 31, broadcast - 1UL, broadcast))}"
    End Sub

    Private Function Ipv4Text(value As ULong) As String
        Return String.Join(".", New String() {
            ((value >> 24) And 255UL).ToString(), ((value >> 16) And 255UL).ToString(),
            ((value >> 8) And 255UL).ToString(), (value And 255UL).ToString()})
    End Function

    Private Sub LoadMaintenance()
        Try
            If File.Exists(maintenanceFile) Then
                Dim records = JsonSerializer.Deserialize(Of List(Of MaintenanceRecord))(File.ReadAllText(maintenanceFile))
                If records IsNot Nothing Then maintenanceRecords.AddRange(records.Where(Function(entry) entry IsNot Nothing))
            End If
        Catch ex As Exception
            MessageBox.Show("Unable to load maintenance records: " & ex.Message, "FixFlowIT", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Function SaveMaintenance() As Boolean
        Try
            Directory.CreateDirectory(Path.GetDirectoryName(maintenanceFile))
            Dim tempPath = maintenanceFile & ".tmp"
            File.WriteAllText(tempPath, JsonSerializer.Serialize(maintenanceRecords, New JsonSerializerOptions With {.WriteIndented = True}))
            File.Move(tempPath, maintenanceFile, True)
            Return True
        Catch ex As Exception
            MessageBox.Show("Unable to save maintenance: " & ex.Message, "FixFlowIT", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Sub BuildMaintenancePage()
        Dim page = AddPage("Maintenance Tracker")
        page.AutoScroll = True
        AddOpsLabel(page, "MAINTENANCE TRACKER  /  Schedule and document work", 25, 12, 800)
        AddOpsLabel(page, "Task / repair title *", 25, 52, 260)
        AddOpsText(page, maintenanceTitle, 25, 80, 315)
        AddOpsLabel(page, "Technician", 360, 52, 220)
        AddOpsText(page, maintenanceTech, 360, 80, 250)
        AddOpsLabel(page, "Status", 635, 52, 160)
        AddOpsChoice(page, maintenanceStatus, 635, 80, 195)
        maintenanceStatus.Items.AddRange(New Object() {"Scheduled", "In Progress", "Completed", "Cancelled"})
        maintenanceStatus.SelectedIndex = 0
        AddOpsLabel(page, "Scheduled date", 25, 124, 210)
        maintenanceDate.SetBounds(25, 151, 315, 30)
        maintenanceDate.Format = DateTimePickerFormat.Short
        page.Controls.Add(maintenanceDate)
        AddOpsLabel(page, "Customer", 360, 124, 210)
        AddOpsChoice(page, maintenanceCustomer, 360, 151, 250)
        AddOpsLabel(page, "Device", 635, 124, 210)
        AddOpsChoice(page, maintenanceDevice, 635, 151, 315)
        AddOpsLabel(page, "Related ticket", 25, 195, 220)
        AddOpsChoice(page, maintenanceTicket, 25, 222, 315)
        AddOpsLabel(page, "Labor hours", 360, 195, 125)
        maintenanceHours.SetBounds(360, 222, 120, 30)
        maintenanceHours.Maximum = 100000D
        maintenanceHours.DecimalPlaces = 2
        maintenanceHours.Increment = 0.25D
        page.Controls.Add(maintenanceHours)
        AddOpsLabel(page, "Hourly rate ($)", 500, 195, 130)
        maintenanceRate.SetBounds(500, 222, 120, 30)
        maintenanceRate.Maximum = 100000D
        maintenanceRate.DecimalPlaces = 2
        page.Controls.Add(maintenanceRate)
        AddOpsLabel(page, "Parts cost ($)", 640, 195, 160)
        maintenancePartsCost.SetBounds(640, 222, 120, 30)
        maintenancePartsCost.Maximum = 10000000D
        maintenancePartsCost.DecimalPlaces = 2
        page.Controls.Add(maintenancePartsCost)
        AddOpsLabel(page, "Work performed / resolution", 25, 264, 350)
        AddOpsText(page, maintenanceWork, 25, 292, 500, 75)
        maintenanceWork.Multiline = True
        maintenanceWork.ScrollBars = ScrollBars.Vertical
        AddOpsLabel(page, "Parts used", 548, 264, 230)
        AddOpsText(page, maintenanceParts, 548, 292, 400, 75)
        maintenanceParts.Multiline = True
        maintenanceParts.ScrollBars = ScrollBars.Vertical
        page.Controls.Add(MakeButton("Add Record", 25, 382, 140, AddressOf AddMaintenance))
        page.Controls.Add(MakeButton("Update Selected", 177, 382, 165, AddressOf UpdateMaintenance))
        page.Controls.Add(MakeButton("Delete Selected", 354, 382, 165, AddressOf DeleteMaintenance))
        page.Controls.Add(MakeButton("Clear Form", 531, 382, 140, AddressOf ClearMaintenance))
        maintenanceInfo.SetBounds(25, 433, 1030, 25)
        page.Controls.Add(maintenanceInfo)
        ConfigureOpsGrid(maintenanceGrid)
        maintenanceGrid.SetBounds(25, 465, 1090, 250)
        maintenanceGrid.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        AddHandler maintenanceGrid.SelectionChanged, AddressOf SelectMaintenance
        page.Controls.Add(maintenanceGrid)
    End Sub

    Private Sub FillChoices(choice As ComboBox, options As IEnumerable(Of RecordChoice), Optional preferredId As Integer = 0)
        choice.Items.Clear()
        choice.Items.Add(New RecordChoice With {.Id = 0, .Label = "None / Unassigned"})
        For Each optionItem In options
            choice.Items.Add(optionItem)
        Next
        choice.SelectedIndex = 0
        For index As Integer = 0 To choice.Items.Count - 1
            If DirectCast(choice.Items(index), RecordChoice).Id = preferredId Then
                choice.SelectedIndex = index
                Exit For
            End If
        Next
    End Sub

    Private Function ChoiceId(choice As ComboBox) As Integer
        Dim chosen = TryCast(choice.SelectedItem, RecordChoice)
        Return If(chosen Is Nothing, 0, chosen.Id)
    End Function

    Private Sub RefreshMaintenanceChoices()
        Dim customerId = ChoiceId(maintenanceCustomer)
        Dim deviceId = ChoiceId(maintenanceDevice)
        Dim ticketId = ChoiceId(maintenanceTicket)
        FillChoices(maintenanceCustomer, customers.Select(Function(entry) New RecordChoice With {.Id = entry.Id, .Label = $"#{entry.Id} {entry.FirstName} {entry.LastName}"}), customerId)
        FillChoices(maintenanceDevice, devices.Select(Function(entry) New RecordChoice With {.Id = entry.Id, .Label = $"#{entry.Id} {entry.AssetTag} — {entry.DeviceName}"}), deviceId)
        FillChoices(maintenanceTicket, tickets.Select(Function(entry) New RecordChoice With {.Id = entry.Id, .Label = $"#{entry.Id} {entry.Title}"}), ticketId)
    End Sub

    Private Sub RefreshMaintenance()
        RefreshMaintenanceChoices()
        maintenanceGrid.DataSource = Nothing
        maintenanceGrid.DataSource = maintenanceRecords.OrderByDescending(Function(entry) entry.Id).Select(Function(entry) New With {
            entry.Id, entry.TaskTitle, entry.Status, entry.ScheduledDate, entry.CompletedDate,
            entry.Technician, entry.CustomerId, entry.DeviceId, entry.TicketId,
            .TotalCost = entry.PartsCost + entry.LaborHours * entry.LaborRate
        }).ToList()
        maintenanceGrid.ClearSelection()
        maintenanceInfo.Text = $"{maintenanceRecords.Count} maintenance records • {maintenanceRecords.Where(Function(entry) entry.Status = "Completed").Count()} completed"
    End Sub

    Private Function ValidMaintenance(Optional editId As Integer = -1) As Boolean
        If String.IsNullOrWhiteSpace(maintenanceTitle.Text) Then
            MessageBox.Show("Enter a task or repair title.")
            Return False
        End If
        Dim deviceId = ChoiceId(maintenanceDevice)
        Dim customerId = ChoiceId(maintenanceCustomer)
        Dim ticketId = ChoiceId(maintenanceTicket)
        Dim linkedDevice = devices.FirstOrDefault(Function(entry) entry.Id = deviceId)
        Dim linkedTicket = tickets.FirstOrDefault(Function(entry) entry.Id = ticketId)
        If linkedDevice IsNot Nothing AndAlso customerId <> 0 AndAlso linkedDevice.CustomerId <> 0 AndAlso linkedDevice.CustomerId <> customerId Then
            MessageBox.Show("The selected device belongs to a different customer.")
            Return False
        End If
        If linkedTicket IsNot Nothing AndAlso linkedTicket.DeviceId <> 0 AndAlso deviceId <> 0 AndAlso linkedTicket.DeviceId <> deviceId Then
            MessageBox.Show("This maintenance record's device does not match the registered device linked to the selected ticket.")
            Return False
        End If
        If linkedTicket IsNot Nothing AndAlso customerId <> 0 AndAlso linkedTicket.CustomerId <> 0 AndAlso linkedTicket.CustomerId <> customerId Then
            MessageBox.Show("The selected ticket belongs to a different customer.")
            Return False
        End If
        Return True
    End Function

    Private Sub ApplyMaintenanceFields(entry As MaintenanceRecord)
        entry.TaskTitle = maintenanceTitle.Text.Trim()
        entry.Technician = maintenanceTech.Text.Trim()
        entry.Status = maintenanceStatus.Text
        entry.ScheduledDate = maintenanceDate.Value.Date
        entry.CustomerId = ChoiceId(maintenanceCustomer)
        entry.DeviceId = ChoiceId(maintenanceDevice)
        entry.TicketId = ChoiceId(maintenanceTicket)
        entry.WorkPerformed = maintenanceWork.Text.Trim()
        entry.PartsUsed = maintenanceParts.Text.Trim()
        entry.LaborHours = maintenanceHours.Value
        entry.LaborRate = maintenanceRate.Value
        entry.PartsCost = maintenancePartsCost.Value
        If entry.Status = "Completed" Then
            If Not entry.CompletedDate.HasValue Then entry.CompletedDate = DateTime.Now
        Else
            entry.CompletedDate = Nothing
        End If
        entry.Updated = DateTime.Now
    End Sub

    Private Sub AddMaintenance(sender As Object, e As EventArgs)
        If Not ValidMaintenance() Then Return
        Dim newId As Integer = If(maintenanceRecords.Count = 0, 1, maintenanceRecords.Max(Function(existingRecord) existingRecord.Id) + 1)
        Dim entry As New MaintenanceRecord With {.Id = newId}
        ApplyMaintenanceFields(entry)
        maintenanceRecords.Add(entry)
        If Not SaveMaintenance() Then
            maintenanceRecords.Remove(entry)
            Return
        End If
        ResetMaintenanceFields()
        RefreshOperations()
    End Sub

    Private Sub SelectMaintenance(sender As Object, e As EventArgs)
        If maintenanceGrid.SelectedRows.Count = 0 Then Return
        Dim selectedValue = maintenanceGrid.SelectedRows(0).Cells("Id").Value
        If selectedValue Is Nothing Then Return
        selectedMaintenanceId = Convert.ToInt32(selectedValue)
        Dim entry = maintenanceRecords.FirstOrDefault(Function(recordItem) recordItem.Id = selectedMaintenanceId)
        If entry Is Nothing Then Return
        maintenanceTitle.Text = entry.TaskTitle
        maintenanceTech.Text = entry.Technician
        maintenanceStatus.SelectedItem = entry.Status
        maintenanceDate.Value = entry.ScheduledDate
        FillChoices(maintenanceCustomer, customers.Select(Function(customerItem) New RecordChoice With {.Id = customerItem.Id, .Label = $"#{customerItem.Id} {customerItem.FirstName} {customerItem.LastName}"}), entry.CustomerId)
        FillChoices(maintenanceDevice, devices.Select(Function(deviceItem) New RecordChoice With {.Id = deviceItem.Id, .Label = $"#{deviceItem.Id} {deviceItem.AssetTag} — {deviceItem.DeviceName}"}), entry.DeviceId)
        FillChoices(maintenanceTicket, tickets.Select(Function(ticketItem) New RecordChoice With {.Id = ticketItem.Id, .Label = $"#{ticketItem.Id} {ticketItem.Title}"}), entry.TicketId)
        maintenanceWork.Text = entry.WorkPerformed
        maintenanceParts.Text = entry.PartsUsed
        maintenanceHours.Value = Math.Min(maintenanceHours.Maximum, Math.Max(maintenanceHours.Minimum, entry.LaborHours))
        maintenanceRate.Value = Math.Min(maintenanceRate.Maximum, Math.Max(maintenanceRate.Minimum, entry.LaborRate))
        maintenancePartsCost.Value = Math.Min(maintenancePartsCost.Maximum, Math.Max(maintenancePartsCost.Minimum, entry.PartsCost))
    End Sub

    Private Sub UpdateMaintenance(sender As Object, e As EventArgs)
        Dim entry = maintenanceRecords.FirstOrDefault(Function(recordItem) recordItem.Id = selectedMaintenanceId)
        If entry Is Nothing Then
            MessageBox.Show("Select a maintenance record first.")
            Return
        End If
        If Not ValidMaintenance(entry.Id) Then Return
        Dim original = JsonSerializer.Deserialize(Of MaintenanceRecord)(JsonSerializer.Serialize(entry))
        Dim recordIndex = maintenanceRecords.IndexOf(entry)
        ApplyMaintenanceFields(entry)
        If Not SaveMaintenance() Then
            maintenanceRecords(recordIndex) = original
            Return
        End If
        ResetMaintenanceFields()
        RefreshOperations()
    End Sub

    Private Sub DeleteMaintenance(sender As Object, e As EventArgs)
        Dim entry = maintenanceRecords.FirstOrDefault(Function(recordItem) recordItem.Id = selectedMaintenanceId)
        If entry Is Nothing Then
            MessageBox.Show("Select a maintenance record first.")
            Return
        End If
        If MessageBox.Show($"Delete maintenance record #{entry.Id}?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) <> DialogResult.Yes Then Return
        Dim recordIndex = maintenanceRecords.IndexOf(entry)
        maintenanceRecords.RemoveAt(recordIndex)
        If Not SaveMaintenance() Then
            maintenanceRecords.Insert(recordIndex, entry)
            Return
        End If
        ResetMaintenanceFields()
        RefreshOperations()
    End Sub

    Private Sub ResetMaintenanceFields()
        selectedMaintenanceId = -1
        maintenanceTitle.Clear()
        maintenanceTech.Clear()
        maintenanceWork.Clear()
        maintenanceParts.Clear()
        maintenanceStatus.SelectedIndex = 0
        maintenanceDate.Value = DateTime.Today
        maintenanceHours.Value = 0D
        maintenanceRate.Value = 0D
        maintenancePartsCost.Value = 0D
        RefreshMaintenanceChoices()
        maintenanceCustomer.SelectedIndex = 0
        maintenanceDevice.SelectedIndex = 0
        maintenanceTicket.SelectedIndex = 0
        maintenanceGrid.ClearSelection()
    End Sub

    Private Sub ClearMaintenance(sender As Object, e As EventArgs)
        ResetMaintenanceFields()
    End Sub

    Private Sub BuildRepairHistoryPage()
        Dim page = AddPage("Repair History")
        page.AutoScroll = True
        AddOpsLabel(page, "REPAIR HISTORY  /  Completed maintenance and repair records", 25, 22, 880)
        AddOpsLabel(page, "Search by task, technician, customer ID, asset or ticket", 25, 73, 780)
        AddOpsText(page, repairSearch, 25, 103, 550)
        AddHandler repairSearch.TextChanged, Sub(sender, e) RefreshRepairHistory()
        ConfigureOpsGrid(repairGrid)
        repairGrid.SetBounds(25, 158, 1090, 300)
        repairGrid.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        AddHandler repairGrid.SelectionChanged, AddressOf SelectRepairHistory
        page.Controls.Add(repairGrid)
        AddOpsLabel(page, "Selected repair details", 25, 485, 350)
        repairDetail.SetBounds(25, 515, 1090, 165)
        repairDetail.Multiline = True
        repairDetail.ReadOnly = True
        repairDetail.ScrollBars = ScrollBars.Vertical
        page.Controls.Add(repairDetail)
        AddOpsLabel(page, "Complete a record in Maintenance Tracker to add it here. Original ticket notes remain in Support Tickets.", 25, 697, 1050)
    End Sub

    Private Sub RefreshRepairHistory()
        Dim search = repairSearch.Text.Trim()
        repairGrid.DataSource = Nothing
        repairGrid.DataSource = maintenanceRecords.Where(Function(entry) entry.Status = "Completed" AndAlso
            (search.Length = 0 OrElse (entry.TaskTitle & " " & entry.Technician & " " & entry.CustomerId.ToString() & " " & entry.TicketId.ToString() & " " & entry.DeviceId.ToString() & " " & DeviceAsset(entry.DeviceId)).IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0)).
            OrderByDescending(Function(entry) entry.CompletedDate).
            Select(Function(entry) New With {entry.Id, entry.CompletedDate, entry.TaskTitle, entry.Technician,
                .Customer = CustomerDisplay(entry.CustomerId), .Device = DeviceAsset(entry.DeviceId), entry.TicketId,
                .TotalCost = entry.PartsCost + entry.LaborHours * entry.LaborRate}).ToList()
        repairGrid.ClearSelection()
        repairDetail.Clear()
    End Sub

    Private Function DeviceAsset(deviceId As Integer) As String
        Dim found = devices.FirstOrDefault(Function(entry) entry.Id = deviceId)
        Return If(found Is Nothing, "Unassigned", found.AssetTag)
    End Function

    Private Function CustomerDisplay(customerId As Integer) As String
        Dim found = customers.FirstOrDefault(Function(entry) entry.Id = customerId)
        Return If(found Is Nothing, "Unassigned", found.FirstName & " " & found.LastName)
    End Function

    Private Sub SelectRepairHistory(sender As Object, e As EventArgs)
        If repairGrid.SelectedRows.Count = 0 Then Return
        Dim rawValue = repairGrid.SelectedRows(0).Cells("Id").Value
        If rawValue Is Nothing Then Return
        Dim selectedIdValue = Convert.ToInt32(rawValue)
        Dim entry = maintenanceRecords.FirstOrDefault(Function(recordItem) recordItem.Id = selectedIdValue)
        If entry Is Nothing Then Return
        Dim ticketEntry = tickets.FirstOrDefault(Function(ticketItem) ticketItem.Id = entry.TicketId)
        repairDetail.Text = $"Repair #{entry.Id} — {entry.TaskTitle}{Environment.NewLine}" &
            $"Customer: {CustomerDisplay(entry.CustomerId)}  Device: {DeviceAsset(entry.DeviceId)}  Ticket: #{entry.TicketId}{Environment.NewLine}" &
            $"Technician: {entry.Technician}  Completed: {entry.CompletedDate}{Environment.NewLine}" &
            $"Work: {entry.WorkPerformed}{Environment.NewLine}Parts: {entry.PartsUsed}{Environment.NewLine}" &
            $"Labor: {entry.LaborHours} hours × ${entry.LaborRate:F2}  Parts cost: ${entry.PartsCost:F2}{Environment.NewLine}" &
            If(ticketEntry Is Nothing, "", "Customer's original description: " & ticketEntry.CustomerDescription)
    End Sub

    Private Sub BuildReportsPage()
        Dim page = AddPage("Reports & Analytics")
        page.AutoScroll = True
        AddOpsLabel(page, "REPORTS & ANALYTICS  /  Operational overview", 25, 22, 900)
        reportSummary.SetBounds(25, 68, 1070, 145)
        reportSummary.Font = New Font("Segoe UI", 14.0F, FontStyle.Bold)
        page.Controls.Add(reportSummary)
        AddOpsLabel(page, "Report type", 25, 235, 200)
        AddOpsChoice(page, reportKind, 25, 264, 340)
        reportKind.Items.AddRange(New Object() {"Ticket Status", "Ticket Priority", "Ticket Deadlines", "Device Condition", "Maintenance Status", "Technician Workload"})
        reportKind.SelectedIndex = 0
        AddHandler reportKind.SelectedIndexChanged, Sub(sender, e) RefreshReports()
        page.Controls.Add(MakeButton("Refresh", 385, 261, 145, AddressOf RefreshReportsClick))
        page.Controls.Add(MakeButton("Export CSV", 545, 261, 165, AddressOf ExportReport))
        ConfigureOpsGrid(reportGrid)
        reportGrid.SetBounds(25, 322, 1090, 355)
        reportGrid.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        page.Controls.Add(reportGrid)
        AddOpsLabel(page, "Reports use the data stored in this console. CSV files can be opened in Excel.", 25, 690, 930)
    End Sub

    Private Sub RefreshReportsClick(sender As Object, e As EventArgs)
        RefreshReports()
    End Sub

    Private Sub RefreshReports()
        If reportKind.SelectedItem Is Nothing Then Return
        Dim openTickets = tickets.Where(Function(entry) Not IsTicketClosed(entry)).Count()
        Dim completedRepairs = maintenanceRecords.Where(Function(entry) entry.Status = "Completed").Count()
        Dim totalCosts = maintenanceRecords.Where(Function(entry) entry.Status = "Completed").Sum(Function(entry) entry.PartsCost + entry.LaborHours * entry.LaborRate)
        Dim overdueCount As Integer = tickets.Where(Function(entry) TicketDeadlineState(entry) = "Overdue").Count()
        Dim partsWaiting As Integer = tickets.Where(Function(entry) entry.Status = "Waiting on Parts").Count()
        reportSummary.Text = $"CUSTOMERS  {customers.Count}        DEVICES  {devices.Count}        TICKETS  {tickets.Count}{Environment.NewLine}" &
            $"ACTIVE  {openTickets}        OVERDUE  {overdueCount}        WAITING ON PARTS  {partsWaiting}{Environment.NewLine}" &
            $"COMPLETED REPAIRS  {completedRepairs}{Environment.NewLine}" &
            $"ESTIMATED COMPLETED REPAIR COSTS  ${totalCosts:N2}"
        Dim data As New List(Of ReportRow)()
        Select Case reportKind.Text
            Case "Ticket Status"
                For Each statusName As String In {"Open", "In Progress", "Waiting on Customer", "Waiting on Parts", "Resolved", "Closed"}
                    data.Add(New ReportRow With {.Category = statusName, .Count = tickets.Where(Function(entry) entry.Status = statusName).Count()})
                Next
            Case "Ticket Deadlines"
                For Each stateName As String In {"Overdue", "Due today", "Upcoming", "No due date", "Completed"}
                    data.Add(New ReportRow With {.Category = stateName, .Count = tickets.Where(Function(entry) TicketDeadlineState(entry) = stateName).Count()})
                Next
            Case "Ticket Priority"
                For Each priorityName As String In {"Low", "Medium", "High", "Critical"}
                    data.Add(New ReportRow With {.Category = priorityName, .Count = tickets.Where(Function(entry) entry.Priority = priorityName).Count()})
                Next
            Case "Device Condition"
                For Each conditionName As String In {"Operational", "Needs Repair", "In Repair", "Retired"}
                    data.Add(New ReportRow With {.Category = conditionName, .Count = devices.Where(Function(entry) entry.Condition = conditionName).Count()})
                Next
            Case "Maintenance Status"
                For Each statusName As String In {"Scheduled", "In Progress", "Completed", "Cancelled"}
                    data.Add(New ReportRow With {.Category = statusName, .Count = maintenanceRecords.Where(Function(entry) entry.Status = statusName).Count()})
                Next
            Case "Technician Workload"
                For Each groupItem In maintenanceRecords.GroupBy(Function(entry) If(String.IsNullOrWhiteSpace(entry.Technician), "Unassigned", entry.Technician)).OrderBy(Function(entry) entry.Key)
                    data.Add(New ReportRow With {.Category = groupItem.Key, .Count = groupItem.Count()})
                Next
        End Select
        reportGrid.DataSource = Nothing
        reportGrid.DataSource = data
        reportGrid.ClearSelection()
        summaryLabel.Text = $"{tickets.Count} Tickets     {openTickets} Active     {overdueCount} Overdue     {customers.Count} Customers     {devices.Count} Devices"
    End Sub

    Private Class ReportRow
        Public Property Category As String = ""
        Public Property Count As Integer
    End Class

    Private Sub ExportReport(sender As Object, e As EventArgs)
        RefreshReports()
        Using dialog As New SaveFileDialog With {.Filter = "CSV files (*.csv)|*.csv", .FileName = "FixFlowIT_Report.csv", .Title = "Export FixFlowIT report"}
            If dialog.ShowDialog(Me) <> DialogResult.OK Then Return
            Try
                Dim builder As New StringBuilder("Category,Count" & Environment.NewLine)
                For Each rowItem As DataGridViewRow In reportGrid.Rows
                    If rowItem.IsNewRow Then Continue For
                    Dim categoryText = Convert.ToString(rowItem.Cells("Category").Value)
                    Dim countText = Convert.ToString(rowItem.Cells("Count").Value)
                    builder.AppendLine(CsvValue(categoryText) & "," & CsvValue(countText))
                Next
                File.WriteAllText(dialog.FileName, builder.ToString(), New UTF8Encoding(True))
                MessageBox.Show("Report exported successfully.", "FixFlowIT")
            Catch ex As Exception
                MessageBox.Show("Unable to export report: " & ex.Message, "FixFlowIT", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Function CsvValue(value As String) As String
        Return """" & If(value, "").Replace("""", """""") & """"
    End Function

    Private Sub RefreshOperations()
        RefreshMaintenance()
        RefreshRepairHistory()
        RefreshReports()
        RefreshDashboardWorkflow()
    End Sub
End Class
