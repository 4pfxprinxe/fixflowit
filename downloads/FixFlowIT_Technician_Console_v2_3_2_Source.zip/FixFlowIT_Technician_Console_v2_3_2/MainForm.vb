Imports System
Imports System.Collections.Generic
Imports System.Drawing
Imports System.IO
Imports System.Linq
Imports System.Text.Json
Imports System.Windows.Forms

Public Class TechnicianNote
    Public Property Created As DateTime = DateTime.Now
    Public Property Author As String = ""
    Public Property Text As String = ""
End Class

Public Class TicketActivity
    Public Property Created As DateTime = DateTime.Now
    Public Property Author As String = "Console user"
    Public Property Action As String = ""
    Public Property Details As String = ""
End Class

Public Class CustomerCommunication
    Public Property Created As DateTime = DateTime.Now
    Public Property Direction As String = "Outbound"
    Public Property Channel As String = "Phone"
    Public Property Contact As String = ""
    Public Property Author As String = "Console user"
    Public Property Summary As String = ""
End Class

Public Class SupportTicket
    Public Property Id As Integer
    Public Property Title As String = ""
    Public Property Device As String = ""
    Public Property Priority As String = "Medium"
    Public Property Status As String = "Open"
    Public Property Created As DateTime = DateTime.Now
    Public Property CustomerId As Integer = 0
    Public Property DeviceId As Integer = 0
    Public Property AssignedTechnician As String = ""
    Public Property EstimatedHours As Decimal = 0D
    Public Property EstimatedHourlyRate As Decimal = 0D
    Public Property EstimatedPartsCost As Decimal = 0D
    Public Property CustomerDescription As String = ""
    Public Property TechnicianNotes As New List(Of TechnicianNote)()
    Public Property DueDate As Nullable(Of DateTime)
    Public Property ActivityHistory As New List(Of TicketActivity)()
    Public Property CommunicationHistory As New List(Of CustomerCommunication)()
End Class

Public Class Customer
    Public Property Id As Integer
    Public Property FirstName As String = ""
    Public Property LastName As String = ""
    Public Property Phone As String = ""
    Public Property Email As String = ""
    Public Property CustomerType As String = "Individual"
    Public Property Address As String = ""
    Public Property CustomerNotes As String = ""
End Class

Public Class InventoryDevice
    Public Property Id As Integer
    Public Property AssetTag As String = ""
    Public Property DeviceName As String = ""
    Public Property Category As String = "Desktop"
    Public Property Manufacturer As String = ""
    Public Property Model As String = ""
    Public Property SerialNumber As String = ""
    Public Property OperatingSystem As String = ""
    Public Property IpAddress As String = ""
    Public Property Location As String = ""
    Public Property Condition As String = "Operational"
    Public Property CustomerId As Integer = 0
    Public Property Notes As String = ""
    Public Property Updated As DateTime = DateTime.Now
End Class

Partial Public Class MainForm
    Inherits Form

    Private ReadOnly tickets As New List(Of SupportTicket)()
    Private ReadOnly customers As New List(Of Customer)()
    Private ReadOnly customerFile As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FixFlowIT", "customers.json")
    Private ReadOnly customerGrid As New DataGridView()
    Private ReadOnly firstInput As New TextBox()
    Private ReadOnly lastInput As New TextBox()
    Private ReadOnly phoneInput As New TextBox()
    Private ReadOnly emailInput As New TextBox()
    Private ReadOnly typeInput As New ComboBox()
    Private ReadOnly addressInput As New TextBox()
    Private ReadOnly notesInput As New TextBox()
    Private ReadOnly customerStatus As New Label()
    Private selectedCustomerId As Integer = -1
    Private ReadOnly dataFile As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FixFlowIT", "tickets.json")
    Private ReadOnly tabs As New TabControl()
    Private ReadOnly headerPanel As New Panel()
    Private ReadOnly navigation As New TableLayoutPanel()
    Private ReadOnly navButtons As New List(Of Button)()
    Private ReadOnly headingLabel As New Label()
    Private ReadOnly subheadingLabel As New Label()
    Private ReadOnly devices As New List(Of InventoryDevice)()
    Private ReadOnly deviceFile As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FixFlowIT", "devices.json")
    Private ReadOnly deviceGrid As New DataGridView()
    Private ReadOnly deviceNameInput As New TextBox()
    Private ReadOnly assetInput As New TextBox()
    Private ReadOnly categoryInput As New ComboBox()
    Private ReadOnly manufacturerInput As New TextBox()
    Private ReadOnly modelInput As New TextBox()
    Private ReadOnly serialInput As New TextBox()
    Private ReadOnly osInput As New TextBox()
    Private ReadOnly ipInput As New TextBox()
    Private ReadOnly locationInput As New TextBox()
    Private ReadOnly conditionInput As New ComboBox()
    Private ReadOnly deviceCustomerInput As New ComboBox()
    Private ReadOnly deviceNotesInput As New TextBox()
    Private ReadOnly deviceSearchInput As New TextBox()
    Private ReadOnly deviceStatus As New Label()
    Private selectedDeviceId As Integer = -1
    Private ReadOnly ticketGrid As New DataGridView()
    Private ReadOnly customerPicker As New ComboBox()
    Private ReadOnly customerDescriptionInput As New TextBox()
    Private ReadOnly technicianNameInput As New TextBox()
    Private ReadOnly technicianNoteInput As New TextBox()
    Private ReadOnly noteHistory As New TextBox()
    Private ReadOnly customerHistory As New TextBox()
    Private ReadOnly ticketDevicePicker As New ComboBox()
    Private ReadOnly assignedTechInput As New TextBox()
    Private ReadOnly estimatedHoursInput As New NumericUpDown()
    Private ReadOnly estimatedRateInput As New NumericUpDown()
    Private ReadOnly estimatedPartsInput As New NumericUpDown()
    Private ReadOnly titleInput As New TextBox()
    Private ReadOnly deviceInput As New TextBox()
    Private ReadOnly priorityInput As New ComboBox()
    Private ReadOnly statusInput As New ComboBox()
    Private ReadOnly summaryLabel As New Label()
    Private ReadOnly countLabel As New Label()
    Private ReadOnly statusLabel As New Label()
    Private selectedId As Integer = -1
    Private ReadOnly darkBg As Color = Color.FromArgb(12, 19, 22)
    Private ReadOnly panelBg As Color = Color.FromArgb(23, 34, 38)
    Private ReadOnly green As Color = Color.FromArgb(75, 227, 155)
    Private ReadOnly lightAccent As Color = Color.FromArgb(12, 129, 81)
    Private ReadOnly isLightMode As Boolean = False

    Public Sub New()
        Text = "FixFlowIT | Technician Console"
        Size = New Size(1480, 860)
        MinimumSize = New Size(1220, 680)
        StartPosition = FormStartPosition.CenterScreen
        BackColor = darkBg
        ForeColor = Color.White
        Font = New Font("Segoe UI", 10.0F)
        LoadTickets()
        LoadCustomers()
        LoadDevices()
        LoadMaintenance()
        BuildUi()
        RefreshTickets()
        RefreshCustomers()
        RefreshCustomerPicker()
        RefreshTicketDevicePicker()
        RefreshDeviceCustomerPicker()
        RefreshTicketDevicePicker()
        RefreshDevices()
        ApplyDarkAppearance()
        RefreshMaintenance()
        RefreshRepairHistory()
        RefreshReports()
        RefreshDashboardWorkflow()
    End Sub

    Private Sub ApplyDarkAppearance()
        Dim background As Color = If(isLightMode, Color.FromArgb(244, 248, 246), darkBg)
        Dim surface As Color = If(isLightMode, Color.White, panelBg)
        Dim textColor As Color = If(isLightMode, Color.FromArgb(25, 44, 37), Color.White)
        Dim muted As Color = If(isLightMode, Color.FromArgb(90, 111, 102), Color.Silver)
        Dim accent As Color = If(isLightMode, lightAccent, green)
        BackColor = background
        ForeColor = textColor
        For Each controlItem As Control In Controls
            ThemeControl(controlItem, background, surface, textColor, muted, accent)
        Next
        headingLabel.ForeColor = accent
        subheadingLabel.ForeColor = muted
        navigation.BackColor = surface
        headerPanel.BackColor = surface
        UpdateNavigationStyle()
        tabs.Invalidate()
    End Sub

    Private Sub ThemeControl(controlItem As Control, background As Color, surface As Color, textColor As Color, muted As Color, accent As Color)
        If TypeOf controlItem Is TabControl Then
            controlItem.BackColor = background
            controlItem.ForeColor = textColor
        ElseIf TypeOf controlItem Is TabPage Then
            controlItem.BackColor = background
            controlItem.ForeColor = textColor
        ElseIf TypeOf controlItem Is Panel Then
            controlItem.BackColor = surface
            controlItem.ForeColor = textColor
        ElseIf TypeOf controlItem Is DataGridView Then
            Dim gridItem = DirectCast(controlItem, DataGridView)
            gridItem.EnableHeadersVisualStyles = False
            gridItem.BackgroundColor = surface
            gridItem.GridColor = If(isLightMode, Color.FromArgb(215, 227, 220), Color.FromArgb(58, 75, 69))
            gridItem.ColumnHeadersDefaultCellStyle.BackColor = If(isLightMode, Color.FromArgb(225, 239, 231), Color.FromArgb(35, 54, 47))
            gridItem.ColumnHeadersDefaultCellStyle.ForeColor = textColor
            gridItem.DefaultCellStyle.BackColor = surface
            gridItem.DefaultCellStyle.ForeColor = textColor
            gridItem.DefaultCellStyle.SelectionBackColor = If(isLightMode, Color.FromArgb(201, 233, 216), Color.FromArgb(32, 101, 71))
            gridItem.DefaultCellStyle.SelectionForeColor = textColor
            gridItem.RowHeadersDefaultCellStyle.BackColor = surface
            gridItem.RowHeadersDefaultCellStyle.ForeColor = textColor
            gridItem.AlternatingRowsDefaultCellStyle.BackColor = If(isLightMode, Color.FromArgb(247, 251, 249), Color.FromArgb(28, 41, 40))
            gridItem.AlternatingRowsDefaultCellStyle.ForeColor = textColor
            gridItem.AlternatingRowsDefaultCellStyle.SelectionBackColor = gridItem.DefaultCellStyle.SelectionBackColor
            gridItem.AlternatingRowsDefaultCellStyle.SelectionForeColor = textColor
            gridItem.Invalidate()
        ElseIf TypeOf controlItem Is TextBox Then
            controlItem.BackColor = surface
            controlItem.ForeColor = textColor
        ElseIf TypeOf controlItem Is ComboBox Then
            controlItem.BackColor = surface
            controlItem.ForeColor = textColor
        ElseIf TypeOf controlItem Is Button Then
            controlItem.BackColor = green
            controlItem.ForeColor = Color.FromArgb(5, 35, 24)
        ElseIf TypeOf controlItem Is Label Then
            Dim labelItem = DirectCast(controlItem, Label)
            If labelItem.ForeColor = green OrElse labelItem.ForeColor = lightAccent Then
                labelItem.ForeColor = accent
            ElseIf labelItem.ForeColor = Color.Silver OrElse labelItem.ForeColor = Color.FromArgb(90, 111, 102) Then
                labelItem.ForeColor = muted
            Else
                labelItem.ForeColor = textColor
            End If
        End If
        For Each child As Control In controlItem.Controls
            ThemeControl(child, background, surface, textColor, muted, accent)
        Next
    End Sub

    Private Sub DrawThemeTab(sender As Object, e As DrawItemEventArgs)
        Dim selected = (e.Index = tabs.SelectedIndex)
        Dim tabBackground As Color = If(isLightMode, If(selected, Color.White, Color.FromArgb(225, 239, 231)), If(selected, Color.FromArgb(36, 69, 55), Color.FromArgb(23, 34, 38)))
        Dim tabForeground As Color = If(isLightMode, Color.FromArgb(25, 44, 37), If(selected, green, Color.White))
        Using fill As New SolidBrush(tabBackground)
            e.Graphics.FillRectangle(fill, e.Bounds)
        End Using
        TextRenderer.DrawText(e.Graphics, tabs.TabPages(e.Index).Text, tabs.Font, e.Bounds, tabForeground, TextFormatFlags.HorizontalCenter Or TextFormatFlags.VerticalCenter Or TextFormatFlags.EndEllipsis)
    End Sub

    Private Function MakeLabel(value As String, x As Integer, y As Integer, Optional w As Integer = 150) As Label
        Return New Label With {.Text = value, .Left = x, .Top = y, .Width = w, .Height = 27, .ForeColor = Color.White}
    End Function

    Private Function MakeButton(value As String, x As Integer, y As Integer, w As Integer, handler As EventHandler) As Button
        Dim b As New Button With {.Text = value, .Left = x, .Top = y, .Width = w, .Height = 38, .BackColor = green, .ForeColor = Color.FromArgb(5, 35, 24), .FlatStyle = FlatStyle.Flat, .Font = New Font("Segoe UI", 9.0F, FontStyle.Bold)}
        b.FlatAppearance.BorderSize = 0
        AddHandler b.Click, handler
        Return b
    End Function

    Private Sub BuildUi()
        'Docking order: content first, navigation second, header last.
        'This prevents the content from covering the header or navigation.
        SuspendLayout()
        tabs.Dock = DockStyle.Fill
        tabs.SizeMode = TabSizeMode.Fixed
        tabs.Appearance = TabAppearance.FlatButtons
        tabs.ItemSize = New Size(0, 1)
        tabs.Font = New Font("Segoe UI", 9.0F)
        Controls.Add(tabs)

        navigation.Dock = DockStyle.Top
        navigation.Height = 56
        navigation.RowCount = 1
        navigation.ColumnCount = 8
        navigation.Margin = New Padding(0)
        navigation.Padding = New Padding(8, 7, 8, 7)
        navigation.CellBorderStyle = TableLayoutPanelCellBorderStyle.None
        For i As Integer = 0 To 7
            navigation.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 12.5F))
        Next
        navigation.RowStyles.Add(New RowStyle(SizeType.Percent, 100.0F))
        Controls.Add(navigation)

        headerPanel.Dock = DockStyle.Top
        headerPanel.Height = 96
        headingLabel.Text = "✦  FixFlowIT"
        headingLabel.SetBounds(28, 12, 460, 44)
        headingLabel.Font = New Font("Segoe UI", 24.0F, FontStyle.Bold)
        subheadingLabel.Text = "TECHNICIAN CONSOLE  •  SUPPORT OPERATIONS  •  v2.3"
        subheadingLabel.SetBounds(33, 59, 520, 25)
        subheadingLabel.Font = New Font("Segoe UI", 9.0F)
        headerPanel.Controls.Add(headingLabel)
        headerPanel.Controls.Add(subheadingLabel)
        Controls.Add(headerPanel)
        ResumeLayout(True)

        Dim dashboard = AddPage("Dashboard")
        dashboard.Controls.Add(MakeLabel("Overview", 28, 30, 250))
        summaryLabel.SetBounds(28, 76, 740, 85)
        summaryLabel.Font = New Font("Segoe UI", 18.0F, FontStyle.Bold)
        dashboard.Controls.Add(summaryLabel)
        dashboard.Controls.Add(MakeLabel("Manage tickets in the Support Tickets tab. Data is saved locally on this PC.", 28, 190, 720))
        BuildWorkflowDashboard(dashboard)

        Dim ticketPage = AddPage("Support Tickets")
        'Force a reliable vertical scroll range regardless of anchored child controls.
        ticketPage.AutoScroll = True
        ticketPage.AutoScrollMinSize = New Size(1060, 1740)
        ticketPage.AutoScrollMargin = New Size(24, 48)
        ticketPage.Controls.Add(MakeLabel("Issue / Ticket title", 25, 24))
        titleInput.SetBounds(25, 52, 310, 31)
        ticketPage.Controls.Add(titleInput)
        ticketPage.Controls.Add(MakeLabel("Device / Asset", 355, 24))
        deviceInput.SetBounds(355, 52, 240, 31)
        ticketPage.Controls.Add(deviceInput)
        ticketPage.Controls.Add(MakeLabel("Priority", 25, 95))
        priorityInput.SetBounds(25, 124, 150, 32)
        priorityInput.DropDownStyle = ComboBoxStyle.DropDownList
        priorityInput.Items.AddRange(New Object() {"Low", "Medium", "High", "Critical"})
        priorityInput.SelectedIndex = 1
        ticketPage.Controls.Add(priorityInput)
        ticketPage.Controls.Add(MakeLabel("Status", 195, 95))
        statusInput.SetBounds(195, 124, 150, 32)
        statusInput.DropDownStyle = ComboBoxStyle.DropDownList
        statusInput.Items.AddRange(New Object() {"Open", "In Progress", "Waiting on Customer", "Waiting on Parts", "Resolved", "Closed"})
        statusInput.SelectedIndex = 0
        ticketPage.Controls.Add(statusInput)
        ticketPage.Controls.Add(MakeLabel("Registered device (linked to ticket)", 365, 95, 460))
        ticketDevicePicker.SetBounds(365, 124, 555, 32)
        ticketDevicePicker.DropDownStyle = ComboBoxStyle.DropDownList
        ticketPage.Controls.Add(ticketDevicePicker)
        AddHandler ticketDevicePicker.SelectedIndexChanged, AddressOf TicketDeviceChanged
        ticketPage.Controls.Add(MakeLabel("Customer", 615, 24))
        customerPicker.SetBounds(615, 52, 305, 31)
        customerPicker.DropDownStyle = ComboBoxStyle.DropDownList
        ticketPage.Controls.Add(customerPicker)
        AddHandler customerPicker.SelectedIndexChanged, AddressOf TicketCustomerChanged
        ticketPage.Controls.Add(MakeLabel("Customer's original description (preserved on ticket)", 25, 167, 650))
        customerDescriptionInput.SetBounds(25, 195, 895, 70)
        customerDescriptionInput.Multiline = True
        customerDescriptionInput.ScrollBars = ScrollBars.Vertical
        customerDescriptionInput.MaxLength = 4000
        ticketPage.Controls.Add(customerDescriptionInput)
        ticketPage.Controls.Add(MakeLabel("REPAIR ESTIMATE  /  Enter costs below", 25, 273, 660))
        ticketPage.Controls.Add(MakeLabel("Assigned technician", 25, 310, 240))
        assignedTechInput.SetBounds(25, 340, 230, 30)
        ticketPage.Controls.Add(assignedTechInput)
        ticketPage.Controls.Add(MakeLabel("Estimated labor (hours)", 292, 310, 200))
        estimatedHoursInput.SetBounds(292, 340, 180, 30)
        estimatedHoursInput.DecimalPlaces = 2
        estimatedHoursInput.Maximum = 100000D
        estimatedHoursInput.Increment = 0.25D
        ticketPage.Controls.Add(estimatedHoursInput)
        ticketPage.Controls.Add(MakeLabel("Hourly rate ($)", 528, 310, 210))
        estimatedRateInput.SetBounds(528, 340, 180, 30)
        estimatedRateInput.DecimalPlaces = 2
        estimatedRateInput.Maximum = 100000D
        ticketPage.Controls.Add(estimatedRateInput)
        ticketPage.Controls.Add(MakeLabel("Parts cost ($)", 760, 310, 180))
        estimatedPartsInput.SetBounds(760, 340, 180, 30)
        estimatedPartsInput.DecimalPlaces = 2
        estimatedPartsInput.Maximum = 10000000D
        ticketPage.Controls.Add(estimatedPartsInput)
        ticketPage.Controls.Add(MakeLabel("Technician name (for internal notes)", 25, 397, 275))
        technicianNameInput.SetBounds(25, 428, 250, 30)
        ticketPage.Controls.Add(technicianNameInput)
        ticketPage.Controls.Add(MakeLabel("New internal technician note", 300, 399, 400))
        technicianNoteInput.SetBounds(300, 428, 620, 65)
        technicianNoteInput.Multiline = True
        technicianNoteInput.MaxLength = 4000
        ticketPage.Controls.Add(technicianNoteInput)
        ticketPage.Controls.Add(MakeButton("Add Note to Selected Ticket", 25, 503, 270, AddressOf AddTechnicianNote))
        noteHistory.SetBounds(310, 503, 610, 95)
        noteHistory.Multiline = True
        noteHistory.ReadOnly = True
        noteHistory.ScrollBars = ScrollBars.Vertical
        noteHistory.BackColor = panelBg
        noteHistory.ForeColor = Color.White
        ticketPage.Controls.Add(noteHistory)
        ticketPage.Controls.Add(MakeButton("Add Ticket", 25, 610, 135, AddressOf AddTicket))
        ticketPage.Controls.Add(MakeButton("Update Selected", 172, 610, 160, AddressOf UpdateTicket))
        ticketPage.Controls.Add(MakeButton("Delete Selected", 344, 610, 160, AddressOf DeleteTicket))
        ticketPage.Controls.Add(MakeButton("Clear Form", 516, 610, 125, AddressOf ClearForm))
        ticketPage.Controls.Add(MakeButton("Export Service Summary", 660, 610, 255, AddressOf ExportServiceSummary))
        countLabel.SetBounds(25, 661, 800, 28)
        ticketPage.Controls.Add(countLabel)
        ticketGrid.SetBounds(25, 696, 925, 210)
        'Do not anchor to Bottom on an AutoScroll page: this can suppress the vertical scroll range.
        ticketGrid.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        ticketGrid.BackgroundColor = panelBg
        ticketGrid.BorderStyle = BorderStyle.None
        ticketGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        ticketGrid.ReadOnly = True
        ticketGrid.AllowUserToAddRows = False
        ticketGrid.AllowUserToDeleteRows = False
        ticketGrid.MultiSelect = False
        ticketGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        AddHandler ticketGrid.SelectionChanged, AddressOf SelectTicket
        ticketPage.Controls.Add(ticketGrid)
        statusLabel.SetBounds(25, 1655, 950, 26)
        statusLabel.Anchor = AnchorStyles.Top Or AnchorStyles.Left
        ticketPage.Controls.Add(statusLabel)
        BuildTicketWorkflow(ticketPage)

        BuildCustomerPage()
        BuildDevicePage()
        BuildDiagnosticsPage()
        BuildMaintenancePage()
        BuildRepairHistoryPage()
        BuildReportsPage()
        CreateNavigation()
    End Sub

    Private Sub CreateNavigation()
        navigation.SuspendLayout()
        navigation.Controls.Clear()
        navButtons.Clear()
        For i As Integer = 0 To tabs.TabPages.Count - 1
            Dim b As New Button With {
                .Text = tabs.TabPages(i).Text,
                .Dock = DockStyle.Fill,
                .Margin = New Padding(3, 2, 3, 2),
                .FlatStyle = FlatStyle.Flat,
                .Font = New Font("Segoe UI", 9.0F, FontStyle.Bold),
                .UseVisualStyleBackColor = False,
                .Tag = i
            }
            b.FlatAppearance.BorderSize = 0
            AddHandler b.Click, AddressOf NavigateToPage
            navigation.Controls.Add(b, i, 0)
            navButtons.Add(b)
        Next
        AddHandler tabs.SelectedIndexChanged, Sub(sender, args) UpdateNavigationStyle()
        navigation.ResumeLayout(True)
        UpdateNavigationStyle()
    End Sub

    Private Sub NavigateToPage(sender As Object, e As EventArgs)
        Dim selectedButton = TryCast(sender, Button)
        If selectedButton Is Nothing Then Return
        tabs.SelectedIndex = CInt(selectedButton.Tag)
        UpdateNavigationStyle()
        If tabs.SelectedIndex = 0 Then RefreshDashboardWorkflow()
        If tabs.SelectedIndex = 7 Then RefreshReports()
    End Sub

    Private Sub UpdateNavigationStyle()
        For i As Integer = 0 To navButtons.Count - 1
            Dim selected As Boolean = (tabs.SelectedIndex = i)
            navButtons(i).BackColor = If(selected,
                If(isLightMode, Color.FromArgb(215, 242, 227), Color.FromArgb(31, 82, 60)),
                If(isLightMode, Color.White, Color.FromArgb(25, 39, 40)))
            navButtons(i).ForeColor = If(selected,
                If(isLightMode, lightAccent, green),
                If(isLightMode, Color.FromArgb(35, 57, 47), Color.FromArgb(225, 235, 229)))
            navButtons(i).FlatAppearance.BorderColor = If(isLightMode, lightAccent, green)
            navButtons(i).FlatAppearance.BorderSize = If(selected, 1, 0)
        Next
    End Sub

    Private Sub BuildDevicePage()
        Dim page = AddPage("Device Inventory")
        page.AutoScroll = True
        page.Controls.Add(MakeLabel("DEVICE INVENTORY  /  Register and manage equipment", 24, 14, 740))
        page.Controls.Add(MakeLabel("Device name *", 25, 55, 200))
        deviceNameInput.SetBounds(25, 82, 235, 30) : page.Controls.Add(deviceNameInput)
        page.Controls.Add(MakeLabel("Asset tag *", 278, 55, 190))
        assetInput.SetBounds(278, 82, 200, 30) : page.Controls.Add(assetInput)
        page.Controls.Add(MakeLabel("Device type", 496, 55, 180))
        categoryInput.SetBounds(496, 82, 180, 30)
        categoryInput.DropDownStyle = ComboBoxStyle.DropDownList
        categoryInput.Items.AddRange(New Object() {"Desktop", "Laptop", "Server", "Printer", "Router", "Switch", "Phone", "Tablet", "Other"})
        categoryInput.SelectedIndex = 0 : page.Controls.Add(categoryInput)
        page.Controls.Add(MakeLabel("Manufacturer", 25, 122, 190))
        manufacturerInput.SetBounds(25, 149, 235, 30) : page.Controls.Add(manufacturerInput)
        page.Controls.Add(MakeLabel("Model", 278, 122, 190))
        modelInput.SetBounds(278, 149, 200, 30) : page.Controls.Add(modelInput)
        page.Controls.Add(MakeLabel("Serial number", 496, 122, 190))
        serialInput.SetBounds(496, 149, 235, 30) : page.Controls.Add(serialInput)
        page.Controls.Add(MakeLabel("Operating system", 25, 189, 190))
        osInput.SetBounds(25, 216, 235, 30) : page.Controls.Add(osInput)
        page.Controls.Add(MakeLabel("IP address (optional)", 278, 189, 190))
        ipInput.SetBounds(278, 216, 200, 30) : page.Controls.Add(ipInput)
        page.Controls.Add(MakeLabel("Location", 496, 189, 190))
        locationInput.SetBounds(496, 216, 235, 30) : page.Controls.Add(locationInput)
        page.Controls.Add(MakeLabel("Condition", 25, 256, 190))
        conditionInput.SetBounds(25, 283, 235, 30)
        conditionInput.DropDownStyle = ComboBoxStyle.DropDownList
        conditionInput.Items.AddRange(New Object() {"Operational", "Needs Repair", "In Repair", "Retired"})
        conditionInput.SelectedIndex = 0 : page.Controls.Add(conditionInput)
        page.Controls.Add(MakeLabel("Owner / customer", 278, 256, 190))
        deviceCustomerInput.SetBounds(278, 283, 453, 30)
        deviceCustomerInput.DropDownStyle = ComboBoxStyle.DropDownList
        page.Controls.Add(deviceCustomerInput)
        page.Controls.Add(MakeLabel("Device notes", 25, 324, 200))
        deviceNotesInput.SetBounds(25, 351, 706, 57)
        deviceNotesInput.Multiline = True
        deviceNotesInput.ScrollBars = ScrollBars.Vertical
        deviceNotesInput.MaxLength = 3000
        page.Controls.Add(deviceNotesInput)
        page.Controls.Add(MakeButton("Add Device", 25, 420, 143, AddressOf AddDevice))
        page.Controls.Add(MakeButton("Update Selected", 179, 420, 165, AddressOf UpdateDevice))
        page.Controls.Add(MakeButton("Delete Selected", 355, 420, 165, AddressOf DeleteDevice))
        page.Controls.Add(MakeButton("Clear Form", 531, 420, 143, AddressOf ClearDeviceForm))
        page.Controls.Add(MakeLabel("Search devices", 25, 480, 180))
        deviceSearchInput.SetBounds(25, 507, 460, 30)
        AddHandler deviceSearchInput.TextChanged, Sub(sender, e) RefreshDevices()
        page.Controls.Add(deviceSearchInput)
        deviceStatus.SetBounds(500, 508, 600, 28)
        deviceStatus.Text = "Inventory: 0 shown / 0 total."
        page.Controls.Add(deviceStatus)
        deviceGrid.SetBounds(25, 553, 1090, 210)
        deviceGrid.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        deviceGrid.BackgroundColor = panelBg
        deviceGrid.BorderStyle = BorderStyle.None
        deviceGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        deviceGrid.ReadOnly = True
        deviceGrid.AllowUserToAddRows = False
        deviceGrid.AllowUserToDeleteRows = False
        deviceGrid.MultiSelect = False
        deviceGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        AddHandler deviceGrid.SelectionChanged, AddressOf SelectDevice
        page.Controls.Add(deviceGrid)
    End Sub

    Private Sub LoadDevices()
        Try
            If File.Exists(deviceFile) Then
                Dim loaded = JsonSerializer.Deserialize(Of List(Of InventoryDevice))(File.ReadAllText(deviceFile))
                If loaded IsNot Nothing Then devices.AddRange(loaded.Where(Function(item) item IsNot Nothing))
            End If
        Catch ex As Exception
            MessageBox.Show("Unable to load device inventory: " & ex.Message, "FixFlowIT", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Function SaveDevices() As Boolean
        Try
            Directory.CreateDirectory(Path.GetDirectoryName(deviceFile))
            Dim tmpFile As String = deviceFile & ".tmp"
            File.WriteAllText(tmpFile, JsonSerializer.Serialize(devices, New JsonSerializerOptions With {.WriteIndented = True}))
            File.Move(tmpFile, deviceFile, True)
            Return True
        Catch ex As Exception
            MessageBox.Show("Unable to save device inventory: " & ex.Message, "FixFlowIT", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Sub RefreshDeviceCustomerPicker()
        Dim previous As Integer = 0
        If TypeOf deviceCustomerInput.SelectedItem Is CustomerChoice Then
            previous = DirectCast(deviceCustomerInput.SelectedItem, CustomerChoice).Id
        End If
        deviceCustomerInput.Items.Clear()
        deviceCustomerInput.Items.Add(New CustomerChoice With {.Id = 0, .DisplayName = "Unassigned / Company owned"})
        For Each customerItem In customers.OrderBy(Function(item) item.LastName)
            deviceCustomerInput.Items.Add(New CustomerChoice With {.Id = customerItem.Id, .DisplayName = $"#{customerItem.Id} - {customerItem.FirstName} {customerItem.LastName}"})
        Next
        deviceCustomerInput.SelectedIndex = 0
        For i As Integer = 0 To deviceCustomerInput.Items.Count - 1
            If DirectCast(deviceCustomerInput.Items(i), CustomerChoice).Id = previous Then
                deviceCustomerInput.SelectedIndex = i
                Exit For
            End If
        Next
    End Sub

    Private Sub RefreshDevices()
        If deviceGrid.IsDisposed Then Return
        Dim term As String = deviceSearchInput.Text.Trim()
        Dim filtered = devices.Where(Function(item) term.Length = 0 OrElse
            (item.DeviceName & " " & item.AssetTag & " " & item.SerialNumber & " " &
             item.Manufacturer & " " & item.Model & " " & item.Category & " " & item.Location).
             IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0).
             OrderBy(Function(item) item.Id).
             Select(Function(item) New With {
                item.Id, item.AssetTag, item.DeviceName, item.Category,
                item.Manufacturer, item.Model, item.SerialNumber, item.Condition,
                .Owner = DeviceOwnerName(item.CustomerId), item.Location, item.IpAddress
             }).ToList()
        deviceGrid.DataSource = Nothing
        deviceGrid.DataSource = filtered
        deviceGrid.ClearSelection()
        If tabs.TabPages.Count = 8 Then RefreshOperations()
        If deviceStatus.Text = "" OrElse deviceStatus.Text.StartsWith("Inventory:") Then
            deviceStatus.Text = $"Inventory: {filtered.Count} shown / {devices.Count} total."
        End If
    End Sub

    Private Function DeviceOwnerName(customerId As Integer) As String
        If customerId = 0 Then Return "Unassigned"
        Dim found = customers.FirstOrDefault(Function(item) item.Id = customerId)
        Return If(found Is Nothing, $"Customer #{customerId} (missing)", found.FirstName & " " & found.LastName)
    End Function

    Private Function ValidateDevice(Optional editingId As Integer = -1) As Boolean
        If String.IsNullOrWhiteSpace(deviceNameInput.Text) OrElse String.IsNullOrWhiteSpace(assetInput.Text) Then
            MessageBox.Show("Device name and asset tag are required.")
            Return False
        End If
        If devices.Any(Function(item) item.Id <> editingId AndAlso
            String.Equals(item.AssetTag, assetInput.Text.Trim(), StringComparison.OrdinalIgnoreCase)) Then
            MessageBox.Show("Asset tags must be unique. This tag is already registered.")
            Return False
        End If
        If devices.Any(Function(item) item.Id <> editingId AndAlso
            serialInput.Text.Trim().Length > 0 AndAlso
            String.Equals(item.SerialNumber, serialInput.Text.Trim(), StringComparison.OrdinalIgnoreCase)) Then
            MessageBox.Show("This serial number is already registered.")
            Return False
        End If
        Dim rawIp = ipInput.Text.Trim()
        Dim parsedIp As System.Net.IPAddress = Nothing
        If rawIp <> "" AndAlso (Not System.Net.IPAddress.TryParse(rawIp, parsedIp) OrElse
            parsedIp.AddressFamily <> System.Net.Sockets.AddressFamily.InterNetwork) Then
            MessageBox.Show("Enter a valid IPv4 address or leave it blank.")
            Return False
        End If
        Return True
    End Function

    Private Sub ApplyDeviceFields(item As InventoryDevice)
        item.DeviceName = deviceNameInput.Text.Trim()
        item.AssetTag = assetInput.Text.Trim()
        item.Category = categoryInput.Text
        item.Manufacturer = manufacturerInput.Text.Trim()
        item.Model = modelInput.Text.Trim()
        item.SerialNumber = serialInput.Text.Trim()
        item.OperatingSystem = osInput.Text.Trim()
        item.IpAddress = ipInput.Text.Trim()
        item.Location = locationInput.Text.Trim()
        item.Condition = conditionInput.Text
        item.CustomerId = If(TypeOf deviceCustomerInput.SelectedItem Is CustomerChoice,
            DirectCast(deviceCustomerInput.SelectedItem, CustomerChoice).Id, 0)
        item.Notes = deviceNotesInput.Text.Trim()
        item.Updated = DateTime.Now
    End Sub

    Private Sub AddDevice(sender As Object, e As EventArgs)
        If Not ValidateDevice() Then Return
        Dim nextId = If(devices.Count = 0, 1, devices.Max(Function(existingDevice) existingDevice.Id) + 1)
        Dim item As New InventoryDevice With {.Id = nextId}
        ApplyDeviceFields(item)
        devices.Add(item)
        If Not SaveDevices() Then
            devices.Remove(item)
            Return
        End If
        ResetDeviceFields()
        RefreshDevices()
        deviceStatus.Text = $"Device #{nextId} added."
        If tabs.TabPages.Count = 8 Then RefreshOperations()
    End Sub

    Private Sub SelectDevice(sender As Object, e As EventArgs)
        If deviceGrid.SelectedRows.Count = 0 Then Return
        Dim raw = deviceGrid.SelectedRows(0).Cells("Id").Value
        If raw Is Nothing Then Return
        selectedDeviceId = Convert.ToInt32(raw)
        Dim item = devices.FirstOrDefault(Function(entry) entry.Id = selectedDeviceId)
        If item Is Nothing Then Return
        deviceNameInput.Text = item.DeviceName : assetInput.Text = item.AssetTag
        categoryInput.SelectedItem = item.Category
        manufacturerInput.Text = item.Manufacturer : modelInput.Text = item.Model
        serialInput.Text = item.SerialNumber : osInput.Text = item.OperatingSystem
        ipInput.Text = item.IpAddress : locationInput.Text = item.Location
        conditionInput.SelectedItem = item.Condition
        deviceNotesInput.Text = item.Notes
        deviceCustomerInput.SelectedIndex = 0
        For i As Integer = 0 To deviceCustomerInput.Items.Count - 1
            If DirectCast(deviceCustomerInput.Items(i), CustomerChoice).Id = item.CustomerId Then
                deviceCustomerInput.SelectedIndex = i
                Exit For
            End If
        Next
    End Sub

    Private Sub UpdateDevice(sender As Object, e As EventArgs)
        Dim item = devices.FirstOrDefault(Function(entry) entry.Id = selectedDeviceId)
        If item Is Nothing Then
            MessageBox.Show("Select a device first.")
            Return
        End If
        If Not ValidateDevice(item.Id) Then Return
        Dim original = JsonSerializer.Deserialize(Of InventoryDevice)(JsonSerializer.Serialize(item))
        ApplyDeviceFields(item)
        If Not SaveDevices() Then
            Dim index = devices.IndexOf(item)
            devices(index) = original
            Return
        End If
        Dim updatedId = item.Id
        ResetDeviceFields()
        RefreshDevices()
        deviceStatus.Text = $"Device #{updatedId} updated."
        If tabs.TabPages.Count = 8 Then RefreshOperations()
    End Sub

    Private Sub DeleteDevice(sender As Object, e As EventArgs)
        Dim item = devices.FirstOrDefault(Function(entry) entry.Id = selectedDeviceId)
        If item Is Nothing Then
            MessageBox.Show("Select a device first.")
            Return
        End If
        If tickets.Any(Function(ticketEntry) ticketEntry.DeviceId = item.Id) Then
            MessageBox.Show("This device is linked to support tickets. Reassign those tickets before deleting the device.")
            Return
        End If
        If maintenanceRecords.Any(Function(recordItem) recordItem.DeviceId = item.Id) Then
            MessageBox.Show("This device has maintenance records. Reassign or remove those records first.")
            Return
        End If
        If MessageBox.Show($"Delete device {item.AssetTag}?", "Confirm deletion",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning) <> DialogResult.Yes Then Return
        Dim index = devices.IndexOf(item)
        devices.RemoveAt(index)
        If Not SaveDevices() Then
            devices.Insert(index, item)
            Return
        End If
        ResetDeviceFields()
        RefreshDevices()
        deviceStatus.Text = "Device deleted."
        If tabs.TabPages.Count = 8 Then RefreshOperations()
    End Sub

    Private Sub ResetDeviceFields()
        selectedDeviceId = -1
        deviceNameInput.Clear() : assetInput.Clear() : manufacturerInput.Clear()
        modelInput.Clear() : serialInput.Clear() : osInput.Clear()
        ipInput.Clear() : locationInput.Clear() : deviceNotesInput.Clear()
        categoryInput.SelectedIndex = 0 : conditionInput.SelectedIndex = 0
        If deviceCustomerInput.Items.Count > 0 Then deviceCustomerInput.SelectedIndex = 0
        deviceGrid.ClearSelection()
    End Sub

    Private Sub ClearDeviceForm(sender As Object, e As EventArgs)
        ResetDeviceFields()
        deviceStatus.Text = "Ready to register a device."
    End Sub

    Private Sub BuildCustomerPage()
        Dim p = AddPage("Customer Information")
        p.AutoScroll = True
        p.Controls.Add(MakeLabel("First Name", 25, 20))
        firstInput.SetBounds(25, 49, 205, 31) : p.Controls.Add(firstInput)
        p.Controls.Add(MakeLabel("Last Name", 250, 20))
        lastInput.SetBounds(250, 49, 205, 31) : p.Controls.Add(lastInput)
        p.Controls.Add(MakeLabel("Phone", 475, 20))
        phoneInput.SetBounds(475, 49, 205, 31) : p.Controls.Add(phoneInput)
        p.Controls.Add(MakeLabel("Email", 25, 95))
        emailInput.SetBounds(25, 124, 290, 31) : p.Controls.Add(emailInput)
        p.Controls.Add(MakeLabel("Customer Type", 335, 95))
        typeInput.SetBounds(335, 124, 180, 31)
        typeInput.DropDownStyle = ComboBoxStyle.DropDownList
        typeInput.Items.AddRange(New Object() {"Individual", "Business"})
        typeInput.SelectedIndex = 0 : p.Controls.Add(typeInput)
        p.Controls.Add(MakeLabel("Address (optional)", 25, 167))
        addressInput.SetBounds(25, 196, 655, 31) : p.Controls.Add(addressInput)
        p.Controls.Add(MakeLabel("Customer's Description of the Problem (in their own words)", 25, 240, 650))
        notesInput.SetBounds(25, 268, 655, 90)
        notesInput.Multiline = True
        notesInput.ScrollBars = ScrollBars.Vertical
        notesInput.MaxLength = 4000
        p.Controls.Add(notesInput)
        p.Controls.Add(MakeButton("Add Customer", 25, 378, 145, AddressOf AddCustomer))
        p.Controls.Add(MakeButton("Update Selected", 183, 378, 165, AddressOf UpdateCustomer))
        p.Controls.Add(MakeButton("Delete Selected", 361, 378, 165, AddressOf DeleteCustomer))
        p.Controls.Add(MakeButton("Clear Form", 539, 378, 125, AddressOf ClearCustomerForm))
        customerGrid.SetBounds(25, 438, 925, 170)
        customerGrid.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right Or AnchorStyles.Bottom
        customerGrid.BackgroundColor = panelBg
        customerGrid.BorderStyle = BorderStyle.None
        customerGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        customerGrid.ReadOnly = True
        customerGrid.AllowUserToAddRows = False
        customerGrid.AllowUserToDeleteRows = False
        customerGrid.MultiSelect = False
        customerGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        AddHandler customerGrid.SelectionChanged, AddressOf SelectCustomer
        p.Controls.Add(customerGrid)
        p.Controls.Add(MakeLabel("Customer service history (linked support tickets)", 25, 615, 700))
        customerHistory.SetBounds(25, 645, 925, 125)
        customerHistory.Multiline = True
        customerHistory.ReadOnly = True
        customerHistory.ScrollBars = ScrollBars.Vertical
        customerHistory.BackColor = panelBg
        customerHistory.ForeColor = Color.White
        p.Controls.Add(customerHistory)
        customerStatus.SetBounds(25, 782, 900, 25)
        customerStatus.Text = "Customer profiles are stored locally on this PC."
        p.Controls.Add(customerStatus)
    End Sub

    Private Sub LoadCustomers()
        Try
            If File.Exists(customerFile) Then
                Dim loaded = JsonSerializer.Deserialize(Of List(Of Customer))(File.ReadAllText(customerFile))
                If loaded IsNot Nothing Then customers.AddRange(loaded.Where(Function(c) c IsNot Nothing))
            End If
        Catch ex As Exception
            MessageBox.Show("Unable to load customers: " & ex.Message, "FixFlowIT", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Function SaveCustomers() As Boolean
        Try
            Directory.CreateDirectory(Path.GetDirectoryName(customerFile))
            File.WriteAllText(customerFile, JsonSerializer.Serialize(customers, New JsonSerializerOptions With {.WriteIndented = True}))
            Return True
        Catch ex As Exception
            MessageBox.Show("Unable to save customers: " & ex.Message, "FixFlowIT", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Sub RefreshCustomers()
        customerGrid.DataSource = Nothing
        customerGrid.DataSource = customers.Select(Function(c) New With {c.Id, c.FirstName, c.LastName, c.Phone, c.Email, c.CustomerType, c.Address, c.CustomerNotes}).ToList()
        customerGrid.ClearSelection()
        RefreshCustomerPicker()
        RefreshTicketDevicePicker()
        RefreshDeviceCustomerPicker()
        RefreshTicketDevicePicker()
        RefreshDevices()
        If tabs.TabPages.Count = 8 Then RefreshOperations()
    End Sub

    Private Sub RefreshCustomerPicker()
        Dim previous As Integer = 0
        If TypeOf customerPicker.SelectedItem Is CustomerChoice Then previous = DirectCast(customerPicker.SelectedItem, CustomerChoice).Id
        customerPicker.Items.Clear()
        customerPicker.Items.Add(New CustomerChoice With {.Id = 0, .DisplayName = "Unassigned"})
        For Each c In customers.OrderBy(Function(x) x.LastName)
            customerPicker.Items.Add(New CustomerChoice With {.Id = c.Id, .DisplayName = $"#{c.Id} - {c.FirstName} {c.LastName}"})
        Next
        customerPicker.SelectedIndex = 0
        For i = 0 To customerPicker.Items.Count - 1
            If DirectCast(customerPicker.Items(i), CustomerChoice).Id = previous Then customerPicker.SelectedIndex = i : Exit For
        Next
    End Sub

    Private Class CustomerChoice
        Public Property Id As Integer
        Public Property DisplayName As String
        Public Overrides Function ToString() As String
            Return DisplayName
        End Function
    End Class

    Private Function ValidCustomer() As Boolean
        If String.IsNullOrWhiteSpace(firstInput.Text) OrElse String.IsNullOrWhiteSpace(lastInput.Text) Then
            MessageBox.Show("First and last name are required.")
            Return False
        End If
        If emailInput.Text.Trim() <> "" AndAlso Not emailInput.Text.Contains("@") Then
            MessageBox.Show("Please enter a valid email address or leave it blank.")
            Return False
        End If
        Return True
    End Function

    Private Sub ApplyCustomerFields(c As Customer)
        c.FirstName = firstInput.Text.Trim()
        c.LastName = lastInput.Text.Trim()
        c.Phone = phoneInput.Text.Trim()
        c.Email = emailInput.Text.Trim()
        c.CustomerType = typeInput.Text
        c.Address = addressInput.Text.Trim()
        c.CustomerNotes = notesInput.Text.Trim()
    End Sub

    Private Sub AddCustomer(sender As Object, e As EventArgs)
        If Not ValidCustomer() Then Return
        Dim id = If(customers.Count = 0, 1, customers.Max(Function(customerItem) customerItem.Id) + 1)
        Dim c As New Customer With {.Id = id}
        ApplyCustomerFields(c)
        customers.Add(c)
        If Not SaveCustomers() Then
            customers.Remove(c)
            Return
        End If
        RefreshCustomers() : ResetCustomerFields()
        customerStatus.Text = $"Customer #{id} added."
    End Sub

    Private Sub SelectCustomer(sender As Object, e As EventArgs)
        If customerGrid.SelectedRows.Count = 0 Then Return
        Dim value = customerGrid.SelectedRows(0).Cells("Id").Value
        If value Is Nothing Then Return
        selectedCustomerId = Convert.ToInt32(value)
        Dim c = customers.FirstOrDefault(Function(item) item.Id = selectedCustomerId)
        If c Is Nothing Then Return
        firstInput.Text = c.FirstName : lastInput.Text = c.LastName
        phoneInput.Text = c.Phone : emailInput.Text = c.Email
        typeInput.SelectedItem = c.CustomerType
        addressInput.Text = c.Address
        notesInput.Text = c.CustomerNotes
        Dim related = tickets.Where(Function(t) t.CustomerId = c.Id).OrderByDescending(Function(t) t.Created).ToList()
        Dim ownedDevices = devices.Where(Function(deviceEntry) deviceEntry.CustomerId = c.Id).ToList()
        Dim deviceSummary = If(ownedDevices.Count = 0, "No registered devices.", String.Join(Environment.NewLine, ownedDevices.Select(Function(deviceEntry) $"{deviceEntry.AssetTag} | {deviceEntry.DeviceName} | {deviceEntry.Condition}")))
        Dim ticketSummary = If(related.Count = 0, "No linked tickets yet.", String.Join(Environment.NewLine & Environment.NewLine, related.Select(Function(ticketEntry) $"#{ticketEntry.Id} | {ticketEntry.Created:g} | {ticketEntry.Status} | {ticketEntry.Title}" & Environment.NewLine & "Device: " & DeviceAsset(ticketEntry.DeviceId) & Environment.NewLine & "Customer: " & ticketEntry.CustomerDescription & Environment.NewLine & "Technician notes: " & If(ticketEntry.TechnicianNotes Is Nothing, 0, ticketEntry.TechnicianNotes.Count).ToString())))
        customerHistory.Text = "REGISTERED DEVICES" & Environment.NewLine & deviceSummary & Environment.NewLine & Environment.NewLine & "SERVICE TICKETS" & Environment.NewLine & ticketSummary
    End Sub

    Private Sub UpdateCustomer(sender As Object, e As EventArgs)
        Dim c = customers.FirstOrDefault(Function(item) item.Id = selectedCustomerId)
        If c Is Nothing Then
            MessageBox.Show("Select a customer first.")
            Return
        End If
        If Not ValidCustomer() Then Return
        Dim old = New Customer With {.Id = c.Id, .FirstName = c.FirstName, .LastName = c.LastName, .Phone = c.Phone, .Email = c.Email, .CustomerType = c.CustomerType, .Address = c.Address, .CustomerNotes = c.CustomerNotes}
        ApplyCustomerFields(c)
        If Not SaveCustomers() Then
            c.FirstName = old.FirstName : c.LastName = old.LastName
            c.Phone = old.Phone : c.Email = old.Email
            c.CustomerType = old.CustomerType : c.Address = old.Address
            c.CustomerNotes = old.CustomerNotes
            Return
        End If
        RefreshCustomers() : ResetCustomerFields()
        customerStatus.Text = $"Customer #{c.Id} updated."
    End Sub

    Private Sub DeleteCustomer(sender As Object, e As EventArgs)
        Dim c = customers.FirstOrDefault(Function(item) item.Id = selectedCustomerId)
        If c Is Nothing Then
            MessageBox.Show("Select a customer first.")
            Return
        End If
        If maintenanceRecords.Any(Function(recordItem) recordItem.CustomerId = c.Id) Then
            MessageBox.Show("This customer has linked maintenance records. Reassign those records before deleting the customer.")
            Return
        End If
        If MessageBox.Show($"Delete customer #{c.Id}?", "Confirm delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) <> DialogResult.Yes Then Return
        If tickets.Any(Function(t) t.CustomerId = c.Id) Then
            MessageBox.Show("This customer has linked tickets. Reassign or remove those tickets before deleting the customer.")
            Return
        End If
        If devices.Any(Function(item) item.CustomerId = c.Id) Then
            MessageBox.Show("This customer owns registered devices. Reassign those devices before deleting the customer.")
            Return
        End If
        Dim index = customers.IndexOf(c)
        customers.Remove(c)
        If Not SaveCustomers() Then
            customers.Insert(index, c)
            Return
        End If
        RefreshCustomers() : ResetCustomerFields()
        customerStatus.Text = "Customer deleted."
    End Sub

    Private Sub ResetCustomerFields()
        selectedCustomerId = -1
        firstInput.Clear() : lastInput.Clear() : phoneInput.Clear()
        emailInput.Clear() : addressInput.Clear() : notesInput.Clear()
        typeInput.SelectedIndex = 0
        customerGrid.ClearSelection()
        customerHistory.Clear()
    End Sub

    Private Sub ClearCustomerForm(sender As Object, e As EventArgs)
        ResetCustomerFields()
        customerStatus.Text = "Ready to add a new customer."
    End Sub

    Private Function AddPage(name As String) As TabPage
        Dim page As New TabPage(name) With {.BackColor = darkBg, .ForeColor = Color.White, .Padding = New Padding(10)}
        tabs.TabPages.Add(page)
        Return page
    End Function

    Private Sub LoadTickets()
        Try
            If File.Exists(dataFile) Then
                Dim loaded = JsonSerializer.Deserialize(Of List(Of SupportTicket))(File.ReadAllText(dataFile))
                If loaded IsNot Nothing Then tickets.AddRange(loaded.Where(Function(t) t IsNot Nothing))
            End If
        Catch ex As Exception
            MessageBox.Show("Unable to load saved tickets: " & ex.Message, "FixFlowIT", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Function SaveTickets() As Boolean
        Try
            Directory.CreateDirectory(Path.GetDirectoryName(dataFile))
            Dim tmpFile As String = dataFile & ".tmp"
            File.WriteAllText(tmpFile, JsonSerializer.Serialize(tickets, New JsonSerializerOptions With {.WriteIndented = True}))
            File.Move(tmpFile, dataFile, True)
            Return True
        Catch ex As Exception
            MessageBox.Show("Could not save tickets: " & ex.Message, "FixFlowIT", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Sub TicketCustomerChanged(sender As Object, e As EventArgs)
        RefreshTicketDevicePicker()
    End Sub

    Private Sub TicketDeviceChanged(sender As Object, e As EventArgs)
        Dim chosenId = SelectedTicketDevice()
        If chosenId = 0 Then Return
        Dim linkedDevice = devices.FirstOrDefault(Function(deviceEntry) deviceEntry.Id = chosenId)
        If linkedDevice IsNot Nothing Then deviceInput.Text = linkedDevice.DeviceName & " (" & linkedDevice.AssetTag & ")"
    End Sub

    Private Function SelectedTicketDevice() As Integer
        Dim choice = TryCast(ticketDevicePicker.SelectedItem, CustomerChoice)
        Return If(choice Is Nothing, 0, choice.Id)
    End Function

    Private Sub RefreshTicketDevicePicker(Optional preferredId As Integer = -1)
        If preferredId < 0 Then preferredId = SelectedTicketDevice()
        Dim ownerId = SelectedCustomer()
        ticketDevicePicker.BeginUpdate()
        Try
            ticketDevicePicker.Items.Clear()
            ticketDevicePicker.Items.Add(New CustomerChoice With {.Id = 0, .DisplayName = "Unlinked / manually entered device"})
            For Each deviceEntry In devices.Where(Function(entry) entry.CustomerId = 0 OrElse ownerId = 0 OrElse entry.CustomerId = ownerId).OrderBy(Function(entry) entry.AssetTag)
                ticketDevicePicker.Items.Add(New CustomerChoice With {.Id = deviceEntry.Id, .DisplayName = $"#{deviceEntry.Id} {deviceEntry.AssetTag} — {deviceEntry.DeviceName} ({DeviceOwnerName(deviceEntry.CustomerId)})"})
            Next
            ticketDevicePicker.SelectedIndex = 0
            For index As Integer = 0 To ticketDevicePicker.Items.Count - 1
                If DirectCast(ticketDevicePicker.Items(index), CustomerChoice).Id = preferredId Then
                    ticketDevicePicker.SelectedIndex = index
                    Exit For
                End If
            Next
        Finally
            ticketDevicePicker.EndUpdate()
        End Try
    End Sub

    Private Function ValidTicketDevice() As Boolean
        Dim deviceId = SelectedTicketDevice()
        If deviceId = 0 Then Return True
        Dim linkedDevice = devices.FirstOrDefault(Function(entry) entry.Id = deviceId)
        If linkedDevice Is Nothing Then
            MessageBox.Show("The selected registered device no longer exists.")
            Return False
        End If
        Dim customerId = SelectedCustomer()
        If linkedDevice.CustomerId <> 0 AndAlso linkedDevice.CustomerId <> customerId Then
            MessageBox.Show("The selected device belongs to another customer. Select the correct customer or an unassigned device.")
            Return False
        End If
        Return True
    End Function

    Private Sub RefreshTickets()
        ticketGrid.DataSource = Nothing
        ticketGrid.DataSource = tickets.Select(Function(t) New With {t.Id, t.CustomerId, t.DeviceId, .AssetTag = DeviceAsset(t.DeviceId), t.Title, t.Device, t.AssignedTechnician, .Estimate = t.EstimatedHours * t.EstimatedHourlyRate + t.EstimatedPartsCost, t.Priority, t.Status, .Due = DueDateText(t.DueDate), .Deadline = TicketDeadlineState(t), t.Created}).ToList()
        summaryLabel.Text = $"{tickets.Count} Total Tickets     {tickets.Where(Function(ticketItem) ticketItem.Status = "Open").Count()} Open     {tickets.Where(Function(ticketItem) ticketItem.Status = "Resolved" OrElse ticketItem.Status = "Closed").Count()} Completed"
        countLabel.Text = $"{tickets.Count} tickets saved"
        ticketGrid.ClearSelection()
        If tabs.TabPages.Count = 8 Then
            RefreshOperations()
            RefreshDashboardWorkflow()
        End If
    End Sub

    Private Function ReadFields() As Boolean
        If String.IsNullOrWhiteSpace(titleInput.Text) OrElse String.IsNullOrWhiteSpace(deviceInput.Text) Then
            MessageBox.Show("Enter a ticket title and device name.", "Missing information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return False
        End If
        Return True
    End Function

    Private Sub AddTicket(sender As Object, e As EventArgs)
        If Not ReadFields() OrElse Not ValidTicketDevice() Then Return
        Dim id = If(tickets.Count = 0, 1, tickets.Max(Function(ticketItem) ticketItem.Id) + 1)
        Dim t As New SupportTicket With {.Id = id, .Title = titleInput.Text.Trim(), .Device = deviceInput.Text.Trim(), .Priority = priorityInput.Text, .Status = statusInput.Text, .CustomerId = SelectedCustomer(), .DeviceId = SelectedTicketDevice(), .CustomerDescription = customerDescriptionInput.Text.Trim(), .AssignedTechnician = assignedTechInput.Text.Trim(), .EstimatedHours = estimatedHoursInput.Value, .EstimatedHourlyRate = estimatedRateInput.Value, .EstimatedPartsCost = estimatedPartsInput.Value, .DueDate = SelectedDueDate()}
        t.ActivityHistory.Add(New TicketActivity With {.Author = WorkflowActor(), .Action = "Ticket created", .Details = $"Status: {t.Status}; Priority: {t.Priority}; Assigned: {If(String.IsNullOrWhiteSpace(t.AssignedTechnician), "Unassigned", t.AssignedTechnician)}; Due: {DueDateText(t.DueDate)}"})
        tickets.Add(t)
        If Not SaveTickets() Then tickets.Remove(t) : Return
        RefreshTickets()
        ResetFields()
        statusLabel.Text = $"Ticket #{id} added."
    End Sub

    Private Sub SelectTicket(sender As Object, e As EventArgs)
        If ticketGrid.SelectedRows.Count = 0 Then Return
        Dim value = ticketGrid.SelectedRows(0).Cells("Id").Value
        If value Is Nothing Then Return
        selectedId = Convert.ToInt32(value)
        Dim t = tickets.FirstOrDefault(Function(item) item.Id = selectedId)
        If t Is Nothing Then Return
        titleInput.Text = t.Title
        assignedTechInput.Text = t.AssignedTechnician
        estimatedHoursInput.Value = Math.Min(estimatedHoursInput.Maximum, Math.Max(0D, t.EstimatedHours))
        estimatedRateInput.Value = Math.Min(estimatedRateInput.Maximum, Math.Max(0D, t.EstimatedHourlyRate))
        estimatedPartsInput.Value = Math.Min(estimatedPartsInput.Maximum, Math.Max(0D, t.EstimatedPartsCost))
        deviceInput.Text = t.Device
        priorityInput.SelectedItem = t.Priority
        statusInput.SelectedItem = t.Status
        customerDescriptionInput.Text = t.CustomerDescription
        customerDescriptionInput.ReadOnly = True
        For i = 0 To customerPicker.Items.Count - 1
            If DirectCast(customerPicker.Items(i), CustomerChoice).Id = t.CustomerId Then customerPicker.SelectedIndex = i : Exit For
        Next
        RefreshTicketDevicePicker(t.DeviceId)
        deviceInput.Text = t.Device
        ShowTechnicianNotes(t)
        workflowActorInput.Clear()
        communicationContact.Clear()
        communicationSummary.Clear()
        LoadTicketWorkflow(t)
    End Sub

    Private Sub UpdateTicket(sender As Object, e As EventArgs)
        Dim t = tickets.FirstOrDefault(Function(item) item.Id = selectedId)
        If t Is Nothing Then
            MessageBox.Show("Select a ticket from the table first.")
            Return
        End If
        If Not ReadFields() OrElse Not ValidTicketDevice() Then Return
        Dim old = JsonSerializer.Deserialize(Of SupportTicket)(JsonSerializer.Serialize(t))
        Dim previousStatus As String = t.Status
        Dim previousPriority As String = t.Priority
        Dim previousAssignee As String = t.AssignedTechnician
        Dim previousDeadline As Nullable(Of DateTime) = t.DueDate
        t.Title = titleInput.Text.Trim()
        t.Device = deviceInput.Text.Trim()
        t.Priority = priorityInput.Text
        t.Status = statusInput.Text
        t.CustomerId = SelectedCustomer()
        t.DeviceId = SelectedTicketDevice()
        t.AssignedTechnician = assignedTechInput.Text.Trim()
        t.EstimatedHours = estimatedHoursInput.Value
        t.EstimatedHourlyRate = estimatedRateInput.Value
        t.EstimatedPartsCost = estimatedPartsInput.Value
        t.DueDate = SelectedDueDate()
        If t.ActivityHistory Is Nothing Then t.ActivityHistory = New List(Of TicketActivity)()
        If Not String.Equals(previousStatus, t.Status, StringComparison.Ordinal) Then
            AppendTicketActivity(t, "Status changed", previousStatus & " → " & t.Status)
        End If
        If Not String.Equals(previousPriority, t.Priority, StringComparison.Ordinal) Then
            AppendTicketActivity(t, "Priority changed", previousPriority & " → " & t.Priority)
        End If
        If Not String.Equals(previousAssignee, t.AssignedTechnician, StringComparison.Ordinal) Then
            AppendTicketActivity(t, "Technician assignment changed", If(String.IsNullOrWhiteSpace(previousAssignee), "Unassigned", previousAssignee) & " → " & If(String.IsNullOrWhiteSpace(t.AssignedTechnician), "Unassigned", t.AssignedTechnician))
        End If
        If previousDeadline.HasValue <> t.DueDate.HasValue OrElse
           (previousDeadline.HasValue AndAlso t.DueDate.HasValue AndAlso previousDeadline.Value.Date <> t.DueDate.Value.Date) Then
            AppendTicketActivity(t, "Due date changed", DueDateText(previousDeadline) & " → " & DueDateText(t.DueDate))
        End If
        If Not SaveTickets() Then
            Dim index As Integer = tickets.IndexOf(t)
            tickets(index) = old
            Return
        End If
        RefreshTickets()
        ResetFields()
        statusLabel.Text = $"Ticket #{t.Id} updated."
    End Sub

    Private Sub DeleteTicket(sender As Object, e As EventArgs)
        Dim t = tickets.FirstOrDefault(Function(item) item.Id = selectedId)
        If t Is Nothing Then
            MessageBox.Show("Select a ticket first.")
            Return
        End If
        If maintenanceRecords.Any(Function(recordItem) recordItem.TicketId = t.Id) Then
            MessageBox.Show("This ticket has linked maintenance records. Reassign those records before deleting the ticket.")
            Return
        End If
        If MessageBox.Show($"Delete ticket #{t.Id}?", "Confirm delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) <> DialogResult.Yes Then Return
        Dim position = tickets.IndexOf(t)
        tickets.Remove(t)
        If Not SaveTickets() Then tickets.Insert(position, t) : Return
        RefreshTickets()
        ResetFields()
        statusLabel.Text = "Ticket deleted."
    End Sub

    Private Sub ResetFields()
        selectedId = -1
        titleInput.Clear()
        deviceInput.Clear()
        assignedTechInput.Clear()
        estimatedHoursInput.Value = 0D
        estimatedRateInput.Value = 0D
        estimatedPartsInput.Value = 0D
        priorityInput.SelectedIndex = 1
        statusInput.SelectedIndex = 0
        customerPicker.SelectedIndex = 0
        RefreshTicketDevicePicker(0)
        customerDescriptionInput.ReadOnly = False
        customerDescriptionInput.Clear()
        technicianNoteInput.Clear()
        technicianNameInput.Clear()
        noteHistory.Clear()
        ResetTicketWorkflow()
        ticketGrid.ClearSelection()
    End Sub

    Private Function SelectedCustomer() As Integer
        If TypeOf customerPicker.SelectedItem Is CustomerChoice Then Return DirectCast(customerPicker.SelectedItem, CustomerChoice).Id
        Return 0
    End Function

    Private Sub ShowTechnicianNotes(t As SupportTicket)
        Dim notes = If(t.TechnicianNotes, New List(Of TechnicianNote)())
        noteHistory.Text = If(notes.Count = 0, "No technician notes yet.", String.Join(Environment.NewLine & Environment.NewLine, notes.Select(Function(n) $"{n.Created:g} | {n.Author}" & Environment.NewLine & n.Text)))
    End Sub

    Private Sub AddTechnicianNote(sender As Object, e As EventArgs)
        Dim t = tickets.FirstOrDefault(Function(item) item.Id = selectedId)
        If t Is Nothing Then
            MessageBox.Show("Select a saved ticket before adding a technician note.")
            Return
        End If
        If String.IsNullOrWhiteSpace(technicianNameInput.Text) OrElse String.IsNullOrWhiteSpace(technicianNoteInput.Text) Then
            MessageBox.Show("Enter technician name and note text.")
            Return
        End If
        If t.TechnicianNotes Is Nothing Then t.TechnicianNotes = New List(Of TechnicianNote)()
        Dim note As New TechnicianNote With {.Author = technicianNameInput.Text.Trim(), .Text = technicianNoteInput.Text.Trim()}
        t.TechnicianNotes.Add(note)
        Dim activity = New TicketActivity With {.Author = note.Author, .Action = "Internal note added", .Details = "A technician note was recorded (internal only)."}
        If t.ActivityHistory Is Nothing Then t.ActivityHistory = New List(Of TicketActivity)()
        t.ActivityHistory.Add(activity)
        If Not SaveTickets() Then
            t.TechnicianNotes.Remove(note)
            t.ActivityHistory.Remove(activity)
            Return
        End If
        technicianNoteInput.Clear()
        ShowTechnicianNotes(t)
        LoadTicketWorkflow(t)
        RefreshDashboardWorkflow()
        statusLabel.Text = $"Internal note added to ticket #{t.Id}."
    End Sub

    Private Sub ExportServiceSummary(sender As Object, e As EventArgs)
        Dim chosenTicket = tickets.FirstOrDefault(Function(ticketEntry) ticketEntry.Id = selectedId)
        If chosenTicket Is Nothing Then
            MessageBox.Show("Select a saved support ticket first.", "FixFlowIT")
            Return
        End If
        Dim linkedRepair = maintenanceRecords.Where(Function(recordEntry) recordEntry.TicketId = chosenTicket.Id AndAlso recordEntry.Status = "Completed").OrderBy(Function(recordEntry) recordEntry.CompletedDate).ToList()
        Dim builder As New System.Text.StringBuilder()
        builder.AppendLine("FIXFLOWIT | CUSTOMER SERVICE SUMMARY")
        builder.AppendLine("Generated: " & DateTime.Now.ToString("g"))
        builder.AppendLine("Ticket: #" & chosenTicket.Id.ToString() & " - " & chosenTicket.Title)
        builder.AppendLine("Customer: " & CustomerDisplay(chosenTicket.CustomerId))
        builder.AppendLine("Device: " & If(chosenTicket.DeviceId = 0, chosenTicket.Device, DeviceAsset(chosenTicket.DeviceId) & " - " & chosenTicket.Device))
        builder.AppendLine("Status: " & chosenTicket.Status & " | Priority: " & chosenTicket.Priority)
        builder.AppendLine("Assigned technician: " & If(String.IsNullOrWhiteSpace(chosenTicket.AssignedTechnician), "Unassigned", chosenTicket.AssignedTechnician))
        builder.AppendLine("Target due date: " & DueDateText(chosenTicket.DueDate))
        builder.AppendLine()
        builder.AppendLine("CUSTOMER'S ORIGINAL DESCRIPTION")
        builder.AppendLine(chosenTicket.CustomerDescription)
        builder.AppendLine()
        builder.AppendLine("ESTIMATE (NOT A FINAL INVOICE)")
        builder.AppendLine("Labor: " & chosenTicket.EstimatedHours.ToString("F2") & " hours at " & chosenTicket.EstimatedHourlyRate.ToString("C2") & "/hour")
        builder.AppendLine("Estimated parts: " & chosenTicket.EstimatedPartsCost.ToString("C2"))
        builder.AppendLine("Estimated total: " & (chosenTicket.EstimatedHours * chosenTicket.EstimatedHourlyRate + chosenTicket.EstimatedPartsCost).ToString("C2"))
        builder.AppendLine()
        builder.AppendLine("COMPLETED WORK")
        If linkedRepair.Count = 0 Then
            builder.AppendLine("No completed maintenance records linked to this ticket yet.")
        Else
            Dim actualTotal As Decimal = 0D
            For Each completedEntry In linkedRepair
                Dim cost As Decimal = completedEntry.LaborHours * completedEntry.LaborRate + completedEntry.PartsCost
                actualTotal += cost
                builder.AppendLine("- " & completedEntry.TaskTitle & " (" & If(completedEntry.CompletedDate.HasValue, completedEntry.CompletedDate.Value.ToString("g"), "Date unavailable") & ")")
                builder.AppendLine("  Work: " & completedEntry.WorkPerformed)
                builder.AppendLine("  Parts: " & completedEntry.PartsUsed)
                builder.AppendLine("  Recorded cost: " & cost.ToString("C2"))
            Next
            builder.AppendLine("Recorded completed-work total: " & actualTotal.ToString("C2"))
        End If
        builder.AppendLine()
        builder.AppendLine("Summary for reference only. Estimates and recorded costs may not include tax, fees, or adjustments.")
        Using saveDialog As New SaveFileDialog With {.Filter = "Text documents (*.txt)|*.txt", .FileName = $"FixFlowIT_Ticket_{chosenTicket.Id}_Summary.txt", .Title = "Save customer service summary"}
            If saveDialog.ShowDialog() <> DialogResult.OK Then Return
            Try
                File.WriteAllText(saveDialog.FileName, builder.ToString(), System.Text.Encoding.UTF8)
                MessageBox.Show("Customer service summary saved successfully.", "FixFlowIT")
            Catch ex As Exception
                MessageBox.Show("Unable to save summary: " & ex.Message, "FixFlowIT", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Sub ClearForm(sender As Object, e As EventArgs)
        ResetFields()
        statusLabel.Text = "Ready to add a new ticket."
    End Sub
End Class
