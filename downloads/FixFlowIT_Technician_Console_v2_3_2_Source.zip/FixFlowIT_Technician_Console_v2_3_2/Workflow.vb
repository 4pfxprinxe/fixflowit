Imports System
Imports System.Drawing
Imports System.Linq
Imports System.Collections.Generic
Imports System.Windows.Forms

Partial Public Class MainForm
    Private ReadOnly ticketDuePicker As New DateTimePicker()
    Private ReadOnly workflowActorInput As New TextBox()
    Private ReadOnly deadlineIndicator As New Label()
    Private ReadOnly communicationChannel As New ComboBox()
    Private ReadOnly communicationDirection As New ComboBox()
    Private ReadOnly communicationContact As New TextBox()
    Private ReadOnly communicationSummary As New TextBox()
    Private ReadOnly communicationHistoryView As New TextBox()
    Private ReadOnly activityHistoryView As New TextBox()
    Private ReadOnly dashboardOverdueLabel As New Label()
    Private ReadOnly dashboardPartsLabel As New Label()
    Private ReadOnly dashboardActiveLabel As New Label()
    Private ReadOnly dashboardRepairsLabel As New Label()
    Private ReadOnly dashboardRecentActivity As New TextBox()

    Private Sub MoveTicketLabel(page As TabPage, caption As String, left As Integer, top As Integer, width As Integer)
        Dim targetLabel = page.Controls.OfType(Of Label)().FirstOrDefault(Function(existingLabel) existingLabel.Text = caption)
        If targetLabel Is Nothing Then Throw New InvalidOperationException("Ticket layout label missing: " & caption)
        targetLabel.SetBounds(left, top, width, 28)
    End Sub

    Private Sub MoveTicketButton(page As TabPage, caption As String, left As Integer, top As Integer, width As Integer)
        Dim targetButton = page.Controls.OfType(Of Button)().FirstOrDefault(Function(existingButton) existingButton.Text = caption)
        If targetButton Is Nothing Then Throw New InvalidOperationException("Ticket layout button missing: " & caption)
        targetButton.SetBounds(left, top, width, 38)
    End Sub

    Private Sub BuildTicketWorkflow(page As TabPage)
        page.Controls.Add(MakeLabel("DEADLINE & ACTIVITY", 25, 395, 420))
        page.Controls.Add(MakeLabel("Ticket due date (check box to enable)", 25, 426, 310))
        ticketDuePicker.SetBounds(25, 458, 255, 30)
        ticketDuePicker.Format = DateTimePickerFormat.Short
        ticketDuePicker.ShowCheckBox = True
        ticketDuePicker.Checked = False
        AddHandler ticketDuePicker.ValueChanged, AddressOf PreviewTicketDeadline
        page.Controls.Add(ticketDuePicker)
        'Keep a gap between the adjacent date and author labels. The preceding
        'date label ends at x=335 and used to cover the start of this caption.
        page.Controls.Add(MakeLabel("Change made by (for activity history)", 350, 426, 360))
        workflowActorInput.SetBounds(350, 458, 280, 30)
        workflowActorInput.MaxLength = 100
        page.Controls.Add(workflowActorInput)
        deadlineIndicator.SetBounds(675, 460, 350, 25)
        deadlineIndicator.Text = "No deadline selected"
        page.Controls.Add(deadlineIndicator)

        MoveTicketLabel(page, "Technician name (for internal notes)", 25, 507, 275)
        MoveTicketLabel(page, "New internal technician note", 310, 507, 400)
        technicianNameInput.SetBounds(25, 538, 250, 30)
        technicianNoteInput.SetBounds(310, 538, 610, 70)
        MoveTicketButton(page, "Add Note to Selected Ticket", 25, 621, 270)
        noteHistory.SetBounds(310, 621, 610, 104)
        page.Controls.Add(MakeLabel("CUSTOMER COMMUNICATION LOG  /  Manual records only — no messages are sent", 25, 746, 910))

        page.Controls.Add(MakeLabel("Direction", 25, 780, 170))
        communicationDirection.SetBounds(25, 808, 170, 30)
        communicationDirection.DropDownStyle = ComboBoxStyle.DropDownList
        communicationDirection.Items.AddRange(New Object() {"Inbound", "Outbound"})
        communicationDirection.SelectedIndex = 0
        page.Controls.Add(communicationDirection)

        page.Controls.Add(MakeLabel("Channel", 215, 780, 180))
        communicationChannel.SetBounds(215, 808, 185, 30)
        communicationChannel.DropDownStyle = ComboBoxStyle.DropDownList
        communicationChannel.Items.AddRange(New Object() {"Phone", "Email", "In Person", "Text", "Other"})
        communicationChannel.SelectedIndex = 0
        page.Controls.Add(communicationChannel)

        page.Controls.Add(MakeLabel("Person contacted / caller", 420, 780, 300))
        communicationContact.SetBounds(420, 808, 450, 30)
        communicationContact.MaxLength = 180
        page.Controls.Add(communicationContact)

        page.Controls.Add(MakeLabel("Summary of communication (what was discussed)", 25, 853, 620))
        communicationSummary.SetBounds(25, 884, 895, 72)
        communicationSummary.Multiline = True
        communicationSummary.ScrollBars = ScrollBars.Vertical
        communicationSummary.MaxLength = 4000
        page.Controls.Add(communicationSummary)

        page.Controls.Add(MakeButton("Log Customer Communication", 25, 973, 272, AddressOf LogCustomerCommunication))
        communicationHistoryView.SetBounds(315, 973, 605, 126)
        communicationHistoryView.Multiline = True
        communicationHistoryView.ReadOnly = True
        communicationHistoryView.ScrollBars = ScrollBars.Vertical
        page.Controls.Add(communicationHistoryView)

        page.Controls.Add(MakeLabel("TICKET ACTIVITY HISTORY  /  Status, priority, assignments, deadlines and notes", 25, 1115, 945))
        activityHistoryView.SetBounds(25, 1147, 895, 176)
        activityHistoryView.Multiline = True
        activityHistoryView.ReadOnly = True
        activityHistoryView.ScrollBars = ScrollBars.Vertical
        page.Controls.Add(activityHistoryView)

        MoveTicketButton(page, "Add Ticket", 25, 1361, 135)
        MoveTicketButton(page, "Update Selected", 172, 1361, 160)
        MoveTicketButton(page, "Delete Selected", 344, 1361, 160)
        MoveTicketButton(page, "Clear Form", 516, 1361, 125)
        MoveTicketButton(page, "Export Service Summary", 660, 1361, 255)
        countLabel.SetBounds(25, 1410, 900, 28)
        ticketGrid.SetBounds(25, 1444, 1100, 200)
        ticketGrid.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        statusLabel.SetBounds(25, 1655, 950, 28)
        ResetTicketWorkflow()
    End Sub

    Private Sub PreviewTicketDeadline(sender As Object, e As EventArgs)
        If ticketDuePicker.Checked Then
            Dim chosen = ticketDuePicker.Value.Date
            If chosen < Date.Today Then
                deadlineIndicator.Text = "Deadline is in the past"
                deadlineIndicator.ForeColor = Color.Salmon
            ElseIf chosen = Date.Today Then
                deadlineIndicator.Text = "Due today"
                deadlineIndicator.ForeColor = Color.Khaki
            Else
                deadlineIndicator.Text = "Target date: " & chosen.ToShortDateString()
                deadlineIndicator.ForeColor = green
            End If
        Else
            deadlineIndicator.Text = "No deadline selected"
            deadlineIndicator.ForeColor = Color.Silver
        End If
    End Sub

    Private Function SelectedDueDate() As Nullable(Of DateTime)
        If ticketDuePicker.Checked Then Return ticketDuePicker.Value.Date
        Return Nothing
    End Function

    Private Function DueDateText(value As Nullable(Of DateTime)) As String
        If value.HasValue Then Return value.Value.ToShortDateString()
        Return "Not set"
    End Function

    Private Function WorkflowActor() As String
        Dim actorName As String = workflowActorInput.Text.Trim()
        Return If(String.IsNullOrWhiteSpace(actorName), "Console user (not identified)", actorName)
    End Function

    Private Function IsTicketClosed(ticketEntry As SupportTicket) As Boolean
        Return String.Equals(ticketEntry.Status, "Resolved", StringComparison.OrdinalIgnoreCase) OrElse
               String.Equals(ticketEntry.Status, "Closed", StringComparison.OrdinalIgnoreCase)
    End Function

    Private Function TicketDeadlineState(ticketEntry As SupportTicket) As String
        If IsTicketClosed(ticketEntry) Then Return "Completed"
        If Not ticketEntry.DueDate.HasValue Then Return "No due date"
        If ticketEntry.DueDate.Value.Date < Date.Today Then Return "Overdue"
        If ticketEntry.DueDate.Value.Date = Date.Today Then Return "Due today"
        Return "Upcoming"
    End Function

    Private Sub AppendTicketActivity(ticketEntry As SupportTicket, actionText As String, detailsText As String)
        If ticketEntry.ActivityHistory Is Nothing Then ticketEntry.ActivityHistory = New List(Of TicketActivity)()
        ticketEntry.ActivityHistory.Add(New TicketActivity With {
            .Created = DateTime.Now,
            .Author = WorkflowActor(),
            .Action = actionText,
            .Details = detailsText
        })
    End Sub

    Private Sub LoadTicketWorkflow(ticketEntry As SupportTicket)
        ticketDuePicker.Checked = False
        If ticketEntry.DueDate.HasValue Then
            ticketDuePicker.Value = ticketEntry.DueDate.Value.Date
            ticketDuePicker.Checked = True
        End If
        PreviewTicketDeadline(Nothing, EventArgs.Empty)
        Dim messages = If(ticketEntry.CommunicationHistory, New List(Of CustomerCommunication)())
        If messages.Count = 0 Then
            communicationHistoryView.Text = "No customer communication recorded."
        Else
            Dim messageLines As New List(Of String)()
            For Each contactEntry In messages.OrderByDescending(Function(existingContact) existingContact.Created)
                messageLines.Add($"{contactEntry.Created:g} | {contactEntry.Direction} {contactEntry.Channel} | {contactEntry.Contact} | Recorded by: {contactEntry.Author}" & Environment.NewLine & contactEntry.Summary)
            Next
            communicationHistoryView.Text = String.Join(Environment.NewLine & Environment.NewLine, messageLines)
        End If
        Dim activities = If(ticketEntry.ActivityHistory, New List(Of TicketActivity)())
        If activities.Count = 0 Then
            activityHistoryView.Text = "No activity history for this ticket yet. Older tickets begin collecting activity after upgrading to v2.3."
        Else
            Dim activityLines As New List(Of String)()
            For Each activityEntry In activities.OrderByDescending(Function(existingActivity) existingActivity.Created)
                activityLines.Add($"{activityEntry.Created:g} | {activityEntry.Author} | {activityEntry.Action}" & Environment.NewLine & activityEntry.Details)
            Next
            activityHistoryView.Text = String.Join(Environment.NewLine & Environment.NewLine, activityLines)
        End If
    End Sub

    Private Sub ResetTicketWorkflow()
        ticketDuePicker.Checked = False
        ticketDuePicker.Value = Date.Today
        workflowActorInput.Clear()
        communicationDirection.SelectedIndex = 0
        communicationChannel.SelectedIndex = 0
        communicationContact.Clear()
        communicationSummary.Clear()
        communicationHistoryView.Text = "Select a saved ticket to view communication history."
        activityHistoryView.Text = "Select a saved ticket to view its activity history."
        PreviewTicketDeadline(Nothing, EventArgs.Empty)
    End Sub

    Private Sub LogCustomerCommunication(sender As Object, e As EventArgs)
        Dim ticketEntry = tickets.FirstOrDefault(Function(existingTicket) existingTicket.Id = selectedId)
        If ticketEntry Is Nothing Then
            MessageBox.Show("Select an existing ticket before logging communication.", "FixFlowIT")
            Return
        End If
        If String.IsNullOrWhiteSpace(communicationContact.Text) OrElse String.IsNullOrWhiteSpace(communicationSummary.Text) Then
            MessageBox.Show("Enter who was contacted and what was discussed.", "FixFlowIT")
            Return
        End If
        If ticketEntry.CommunicationHistory Is Nothing Then ticketEntry.CommunicationHistory = New List(Of CustomerCommunication)()
        If ticketEntry.ActivityHistory Is Nothing Then ticketEntry.ActivityHistory = New List(Of TicketActivity)()
        Dim contactEntry As New CustomerCommunication With {
            .Created = DateTime.Now,
            .Author = WorkflowActor(),
            .Contact = communicationContact.Text.Trim(),
            .Summary = communicationSummary.Text.Trim(),
            .Direction = communicationDirection.Text,
            .Channel = communicationChannel.Text
        }
        Dim activityEntry As New TicketActivity With {
            .Created = contactEntry.Created,
            .Author = contactEntry.Author,
            .Action = "Customer contact logged",
            .Details = $"{contactEntry.Direction} {contactEntry.Channel} with {contactEntry.Contact} (summary stored in communication log)."
        }
        ticketEntry.CommunicationHistory.Add(contactEntry)
        ticketEntry.ActivityHistory.Add(activityEntry)
        If Not SaveTickets() Then
            ticketEntry.CommunicationHistory.Remove(contactEntry)
            ticketEntry.ActivityHistory.Remove(activityEntry)
            Return
        End If
        communicationContact.Clear()
        communicationSummary.Clear()
        LoadTicketWorkflow(ticketEntry)
        RefreshDashboardWorkflow()
        statusLabel.Text = $"Customer contact saved to ticket #{ticketEntry.Id}. No message was sent."
    End Sub

    Private Class DashboardTimelineEntry
        Public Property TicketId As Integer
        Public Property Created As DateTime
        Public Property Author As String = ""
        Public Property Action As String = ""
    End Class

    Private Sub BuildWorkflowDashboard(page As TabPage)
        page.AutoScroll = True
        page.Controls.Add(MakeLabel("TICKET WORKFLOW SNAPSHOT", 28, 253, 450))
        dashboardActiveLabel.SetBounds(28, 294, 260, 54)
        dashboardOverdueLabel.SetBounds(302, 294, 260, 54)
        dashboardPartsLabel.SetBounds(576, 294, 290, 54)
        dashboardRepairsLabel.SetBounds(879, 294, 290, 54)
        For Each itemLabel In New Label() {dashboardActiveLabel, dashboardOverdueLabel, dashboardPartsLabel, dashboardRepairsLabel}
            itemLabel.Font = New Font("Segoe UI", 14.0F, FontStyle.Bold)
            itemLabel.ForeColor = green
            page.Controls.Add(itemLabel)
        Next
        page.Controls.Add(MakeLabel("RECENT TICKET ACTIVITY", 28, 380, 550))
        dashboardRecentActivity.SetBounds(28, 417, 1070, 270)
        dashboardRecentActivity.Multiline = True
        dashboardRecentActivity.ReadOnly = True
        dashboardRecentActivity.ScrollBars = ScrollBars.Vertical
        dashboardRecentActivity.Font = New Font("Consolas", 10.0F)
        page.Controls.Add(dashboardRecentActivity)
        page.Controls.Add(MakeLabel("Overdue = unresolved ticket with a due date before today. Customer communication is logged manually.", 28, 707, 1070))
    End Sub

    Private Sub RefreshDashboardWorkflow()
        If dashboardActiveLabel.IsDisposed OrElse dashboardActiveLabel.Parent Is Nothing Then Return
        Dim activeCount = tickets.Where(Function(entry) Not IsTicketClosed(entry)).Count()
        Dim overdueCount = tickets.Where(Function(entry) TicketDeadlineState(entry) = "Overdue").Count()
        Dim partsWaiting = tickets.Where(Function(entry) entry.Status = "Waiting on Parts").Count()
        Dim activeRepairs = maintenanceRecords.Where(Function(entry) entry.Status = "In Progress").Count()
        dashboardActiveLabel.Text = $"{activeCount}  Active Tickets"
        dashboardOverdueLabel.Text = $"{overdueCount}  Overdue Tickets"
        dashboardPartsLabel.Text = $"{partsWaiting}  Waiting on Parts"
        dashboardRepairsLabel.Text = $"{activeRepairs}  Active Repairs"
        dashboardOverdueLabel.ForeColor = If(overdueCount > 0, Color.Salmon, green)
        Dim timeline As New List(Of DashboardTimelineEntry)()
        For Each ticketEntry In tickets
            Dim history = If(ticketEntry.ActivityHistory, New List(Of TicketActivity)())
            For Each activityEntry In history
                timeline.Add(New DashboardTimelineEntry With {.TicketId = ticketEntry.Id, .Created = activityEntry.Created, .Author = activityEntry.Author, .Action = activityEntry.Action})
            Next
        Next
        Dim recent = timeline.OrderByDescending(Function(existingEvent) existingEvent.Created).Take(15).ToList()
        Dim activityLines As New List(Of String)()
        For Each eventItem In recent
            activityLines.Add($"{eventItem.Created:g}   Ticket #{eventItem.TicketId}   {eventItem.Action}   ({eventItem.Author})")
        Next
        dashboardRecentActivity.Text = If(recent.Count = 0, "No ticket activity yet.", String.Join(Environment.NewLine, activityLines))
    End Sub
End Class
