FixFlowIT Technician Console v2.3.1 - Ticket Workflow Management
==============================================================

Built on the confirmed-working FixFlowIT v2.2.1 source. All eight tabs remain
in place, with the established dark theme. No Light/Dark toggle is included.

NEW IN v2.3
- Ticket due dates (optional): check the box beside the date to enable it.
- Status choices: Open, In Progress, Waiting on Customer, Waiting on Parts,
  Resolved, Closed.
- Automatic timestamped activity history for new tickets; changes to status,
  priority, technician assignment, and due date; and newly added technician
  notes and contact records.
- New Customer Communication Log, separate from technician notes: direction,
  channel, contact/person, summary, timestamp, and recorded-by field.
- Dashboard: active tickets, overdue tickets, waiting-on-parts count, in-progress
  maintenance, and 15 most recent ticket activity events.
- Reports & Analytics: new Ticket Deadlines report and updated status counts.
- Support Tickets estimate row: increased spacing for Hourly Rate and Parts Cost.
- Customer-facing service summary includes the due date; internal notes and
  communication details are NOT included in exports.

OPEN / TEST
1. Back up your existing %LOCALAPPDATA%\FixFlowIT folder. (This contains your
   tickets.json, customers.json, devices.json, and maintenance.json.)
2. Extract this ZIP into a NEW folder; do not overwrite the running app folder.
3. Open FixFlowIT.TechnicianConsole.vbproj in Visual Studio 2022.
4. Build > Rebuild Solution. If successful, press F5.
5. In Support Tickets, select a ticket. Set a new status and optional due date,
   fill in Change made by, and click Update Selected. Select the ticket again
   to review its activity history.
6. Select the ticket and log an actual customer interaction using the manual
   Customer Communication Log. It does NOT send an email, text, or message.
7. Review the Dashboard and Reports & Analytics > Ticket Deadlines.
8. Restart the app and confirm the new fields and histories persisted.

NOTE FOR EXISTING TICKETS
Tickets saved in v2.2.1 are compatible. Their due date will be blank and they
will have no historical audit records until new activity occurs in v2.3;
previous changes cannot be retroactively reconstructed.

DATA AND LIMITATIONS
All data is saved locally in %LOCALAPPDATA%\FixFlowIT\tickets.json and other
local JSON files, without authentication or encryption. Use fictional test
data, not real customer personal information, until proper security is added.
The user-entered "Change made by" field is a manual attribution, not a
verified login identity. The communication log records contact, but never
sends messages. Overdue indicators update when pages refresh or the app opens.

BUILD STATUS
Source was reviewed and statically checked. Windows Forms compilation and
visual/run testing require Visual Studio on Windows; this ZIP is not a signed
or precompiled application.

V2.3.1 PATCH
- Corrected overlapping Deadline & Activity labels: moved the Change made by caption and input to the right, adjusted the target-date indicator.
- Data model, workflow logic, and other interface sections unchanged.
